using AsaderoERP.Application.DTOs;
using AsaderoERP.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AsaderoERP.API.Controllers;

// ─── ACTIVOS FIJOS ────────────────────────────────────────────────────────────
[Authorize(Roles = "Administrador")]
public class ActivosFijosController : BaseController
{
    private readonly IActivoFijoService _service;
    public ActivosFijosController(IActivoFijoService service) => _service = service;

    /// <summary>Listar activos fijos</summary>
    [HttpGet]
    public async Task<IActionResult> GetAll() => Ok(await _service.GetAllAsync());

    /// <summary>Obtener activo por ID</summary>
    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetById(int id)
    {
        try { return Ok(await _service.GetByIdAsync(id)); }
        catch (KeyNotFoundException ex) { return NotFound(new { mensaje = ex.Message }); }
    }

    /// <summary>Registrar nuevo activo fijo</summary>
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CrearActivoFijoDto dto)
    {
        try
        {
            var result = await _service.CreateAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = result.Id }, result);
        }
        catch (ArgumentException ex) { return BadRequest(new { mensaje = ex.Message }); }
    }

    /// <summary>Actualizar activo fijo</summary>
    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, [FromBody] ActualizarActivoFijoDto dto)
    {
        try { return Ok(await _service.UpdateAsync(id, dto)); }
        catch (KeyNotFoundException ex) { return NotFound(new { mensaje = ex.Message }); }
    }

    /// <summary>Dar de baja un activo fijo</summary>
    [HttpPatch("{id:int}/dar-de-baja")]
    public async Task<IActionResult> DarDeBaja(int id, [FromBody] DarDeBajaActivoDto dto)
    {
        try
        {
            await _service.DarDeBajaAsync(id, dto);
            return Ok(new { mensaje = "Activo dado de baja correctamente." });
        }
        catch (KeyNotFoundException ex) { return NotFound(new { mensaje = ex.Message }); }
    }
}

// ─── EMPLEADOS ────────────────────────────────────────────────────────────────
[Authorize(Roles = "Administrador")]
public class EmpleadosController : BaseController
{
    private readonly IEmpleadoService _service;
    public EmpleadosController(IEmpleadoService service) => _service = service;

    /// <summary>Listar empleados activos</summary>
    [HttpGet]
    public async Task<IActionResult> GetAll() => Ok(await _service.GetAllAsync());

    /// <summary>Obtener empleado por ID</summary>
    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetById(int id)
    {
        try { return Ok(await _service.GetByIdAsync(id)); }
        catch (KeyNotFoundException ex) { return NotFound(new { mensaje = ex.Message }); }
    }

    /// <summary>Registrar empleado</summary>
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CrearEmpleadoDto dto)
    {
        try
        {
            var result = await _service.CreateAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = result.Id }, result);
        }
        catch (InvalidOperationException ex) { return Conflict(new { mensaje = ex.Message }); }
        catch (ArgumentException ex) { return BadRequest(new { mensaje = ex.Message }); }
    }

    /// <summary>Actualizar datos de empleado</summary>
    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, [FromBody] ActualizarEmpleadoDto dto)
    {
        try { return Ok(await _service.UpdateAsync(id, dto)); }
        catch (KeyNotFoundException ex) { return NotFound(new { mensaje = ex.Message }); }
    }

    /// <summary>Desactivar empleado</summary>
    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Eliminar(int id)
    {
        try
        {
            await _service.EliminarAsync(id);
            return Ok(new { mensaje = "Empleado desactivado correctamente." });
        }
        catch (KeyNotFoundException ex) { return NotFound(new { mensaje = ex.Message }); }
    }

    /// <summary>Registrar entrada de asistencia</summary>
    [HttpPost("asistencia/entrada")]
    public async Task<IActionResult> RegistrarEntrada([FromBody] RegistrarAsistenciaDto dto)
    {
        try { return Ok(await _service.RegistrarEntradaAsync(dto)); }
        catch (KeyNotFoundException ex) { return NotFound(new { mensaje = ex.Message }); }
    }

    /// <summary>Registrar salida de asistencia</summary>
    [HttpPatch("asistencia/{asistenciaId:int}/salida")]
    public async Task<IActionResult> RegistrarSalida(int asistenciaId, [FromBody] RegistrarSalidaDto dto)
    {
        try { return Ok(await _service.RegistrarSalidaAsync(asistenciaId, dto)); }
        catch (KeyNotFoundException ex) { return NotFound(new { mensaje = ex.Message }); }
    }

    /// <summary>Ver asistencias de un empleado</summary>
    [HttpGet("{id:int}/asistencias")]
    public async Task<IActionResult> GetAsistencias(int id)
    {
        try { return Ok(await _service.GetAsistenciasAsync(id)); }
        catch (KeyNotFoundException ex) { return NotFound(new { mensaje = ex.Message }); }
    }

    /// <summary>Calcular nómina de un empleado por periodo</summary>
    [HttpGet("{id:int}/nomina")]
    public async Task<IActionResult> CalcularNomina(int id, [FromQuery] DateTime desde, [FromQuery] DateTime hasta)
    {
        try { return Ok(await _service.CalcularNominaAsync(id, desde, hasta)); }
        catch (KeyNotFoundException ex) { return NotFound(new { mensaje = ex.Message }); }
    }
}

// ─── EIS / DASHBOARD ─────────────────────────────────────────────────────────
[Authorize(Roles = "Gerente,Administrador")]
public class EisController : BaseController
{
    private readonly IEisService _service;
    public EisController(IEisService service) => _service = service;

    /// <summary>Dashboard ejecutivo completo</summary>
    [HttpGet("dashboard")]
    public async Task<IActionResult> GetDashboard() => Ok(await _service.GetDashboardAsync());

    /// <summary>Ventas del día actual</summary>
    [HttpGet("ventas-hoy")]
    public async Task<IActionResult> GetVentasHoy() =>
        Ok(new { fecha = DateTime.UtcNow.Date, total = await _service.GetVentasHoyAsync() });

    /// <summary>Ventas mensuales</summary>
    [HttpGet("ventas-mes")]
    public async Task<IActionResult> GetVentasMes([FromQuery] int? anio, [FromQuery] int? mes)
    {
        var a = anio ?? DateTime.UtcNow.Year;
        var m = mes ?? DateTime.UtcNow.Month;
        return Ok(new { anio = a, mes = m, total = await _service.GetVentasMesAsync(a, m) });
    }

    /// <summary>Producto más vendido</summary>
    [HttpGet("producto-mas-vendido")]
    public async Task<IActionResult> GetProductoMasVendido() =>
        Ok(new { producto = await _service.GetProductoMasVendidoAsync() });

    /// <summary>Ganancias en un periodo</summary>
    [HttpGet("ganancias")]
    public async Task<IActionResult> GetGanancias([FromQuery] DateTime desde, [FromQuery] DateTime hasta) =>
        Ok(new { desde, hasta, ganancias = await _service.GetGananciasAsync(desde, hasta) });

    /// <summary>Productos con bajo stock</summary>
    [HttpGet("bajo-stock")]
    public async Task<IActionResult> GetBajoStock() => Ok(await _service.GetProductosBajoStockAsync());
}
