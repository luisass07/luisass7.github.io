using AsaderoERP.Application.DTOs;
using AsaderoERP.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AsaderoERP.API.Controllers;

[Authorize]
public class FacturasController : BaseController
{
    private readonly IFacturaService _service;
    public FacturasController(IFacturaService service) => _service = service;

    /// <summary>Listar todas las facturas</summary>
    [HttpGet]
    [Authorize(Roles = "Administrador,Gerente")]
    public async Task<IActionResult> GetAll() => Ok(await _service.GetAllAsync());

    /// <summary>Filtrar facturas por rango de fechas</summary>
    [HttpGet("por-fecha")]
    [Authorize(Roles = "Administrador,Gerente")]
    public async Task<IActionResult> GetByFecha([FromQuery] DateTime desde, [FromQuery] DateTime hasta) =>
        Ok(await _service.GetByFechaAsync(desde, hasta));

    /// <summary>Consultar ventas diarias</summary>
    [HttpGet("ventas-dia")]
    [Authorize(Roles = "Administrador,Gerente")]
    public async Task<IActionResult> GetVentasDia([FromQuery] DateTime? fecha)
    {
        var f = fecha ?? DateTime.UtcNow;
        return Ok(new { fecha = f.Date, total = await _service.GetTotalVentasDiaAsync(f) });
    }

    /// <summary>Consultar ventas mensuales</summary>
    [HttpGet("ventas-mes")]
    [Authorize(Roles = "Administrador,Gerente")]
    public async Task<IActionResult> GetVentasMes([FromQuery] int? anio, [FromQuery] int? mes)
    {
        var a = anio ?? DateTime.UtcNow.Year;
        var m = mes ?? DateTime.UtcNow.Month;
        return Ok(new { anio = a, mes = m, total = await _service.GetTotalVentasMesAsync(a, m) });
    }

    /// <summary>Obtener factura por ID</summary>
    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetById(int id)
    {
        try { return Ok(await _service.GetByIdAsync(id)); }
        catch (KeyNotFoundException ex) { return NotFound(new { mensaje = ex.Message }); }
    }

    /// <summary>Generar factura electrónica</summary>
    [HttpPost]
    [Authorize(Roles = "Cajero,Administrador")]
    public async Task<IActionResult> Create([FromBody] CrearFacturaDto dto)
    {
        try
        {
            var result = await _service.CreateAsync(dto, GetUsuarioId());
            return CreatedAtAction(nameof(GetById), new { id = result.Id }, result);
        }
        catch (InvalidOperationException ex) { return BadRequest(new { mensaje = ex.Message }); }
        catch (KeyNotFoundException ex) { return NotFound(new { mensaje = ex.Message }); }
    }

    /// <summary>Anular factura electrónica</summary>
    [HttpPatch("{id:int}/anular")]
    [Authorize(Roles = "Administrador")]
    public async Task<IActionResult> Anular(int id, [FromBody] AnularFacturaDto dto)
    {
        try
        {
            await _service.AnularAsync(id, dto);
            return Ok(new { mensaje = "Factura anulada correctamente." });
        }
        catch (InvalidOperationException ex) { return BadRequest(new { mensaje = ex.Message }); }
        catch (KeyNotFoundException ex) { return NotFound(new { mensaje = ex.Message }); }
    }
}
