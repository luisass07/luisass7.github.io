using AsaderoERP.Application.DTOs;
using AsaderoERP.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AsaderoERP.API.Controllers;

[Authorize(Roles = "Administrador,Gerente")]
public class ProductosController : BaseController
{
    private readonly IProductoService _service;
    public ProductosController(IProductoService service) => _service = service;

    /// <summary>Listar todos los productos en inventario</summary>
    [HttpGet]
    public async Task<IActionResult> GetAll() => Ok(await _service.GetAllAsync());

    /// <summary>Productos con stock mínimo o bajo</summary>
    [HttpGet("bajo-stock")]
    public async Task<IActionResult> GetBajoStock() => Ok(await _service.GetBajoStockAsync());

    /// <summary>Obtener producto por ID</summary>
    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetById(int id)
    {
        try { return Ok(await _service.GetByIdAsync(id)); }
        catch (KeyNotFoundException ex) { return NotFound(new { mensaje = ex.Message }); }
    }

    /// <summary>Registrar producto en inventario</summary>
    [HttpPost]
    [Authorize(Roles = "Administrador")]
    public async Task<IActionResult> Create([FromBody] CrearProductoDto dto)
    {
        try
        {
            var result = await _service.CreateAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = result.Id }, result);
        }
        catch (ArgumentException ex) { return BadRequest(new { mensaje = ex.Message }); }
    }

    /// <summary>Actualizar información de producto</summary>
    [HttpPut("{id:int}")]
    [Authorize(Roles = "Administrador")]
    public async Task<IActionResult> Update(int id, [FromBody] ActualizarProductoDto dto)
    {
        try { return Ok(await _service.UpdateAsync(id, dto)); }
        catch (KeyNotFoundException ex) { return NotFound(new { mensaje = ex.Message }); }
    }

    /// <summary>Ajuste manual de inventario</summary>
    [HttpPatch("ajuste")]
    [Authorize(Roles = "Administrador")]
    public async Task<IActionResult> AjustarInventario([FromBody] AjusteInventarioDto dto)
    {
        try
        {
            await _service.AjustarInventarioAsync(dto);
            return Ok(new { mensaje = "Inventario ajustado correctamente." });
        }
        catch (ArgumentException ex) { return BadRequest(new { mensaje = ex.Message }); }
        catch (KeyNotFoundException ex) { return NotFound(new { mensaje = ex.Message }); }
    }

    /// <summary>Consultar kardex (historial de movimientos) de un producto</summary>
    [HttpGet("{id:int}/kardex")]
    public async Task<IActionResult> GetKardex(int id)
    {
        try { return Ok(await _service.GetKardexAsync(id)); }
        catch (KeyNotFoundException ex) { return NotFound(new { mensaje = ex.Message }); }
    }

    /// <summary>Costo promedio de un producto</summary>
    [HttpGet("{id:int}/costo-promedio")]
    public async Task<IActionResult> GetCostoPromedio(int id)
    {
        try { return Ok(new { productoId = id, costoPromedio = await _service.GetCostoPromedioAsync(id) }); }
        catch (KeyNotFoundException ex) { return NotFound(new { mensaje = ex.Message }); }
    }
}
