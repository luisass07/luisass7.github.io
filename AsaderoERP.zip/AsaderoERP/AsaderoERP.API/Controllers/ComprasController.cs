using AsaderoERP.Application.DTOs;
using AsaderoERP.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AsaderoERP.API.Controllers;

[Authorize(Roles = "Administrador")]
public class ProveedoresController : BaseController
{
    private readonly IProveedorService _service;
    public ProveedoresController(IProveedorService service) => _service = service;

    /// <summary>Listar todos los proveedores</summary>
    [HttpGet]
    public async Task<IActionResult> GetAll() =>
        Ok(await _service.GetAllAsync());

    /// <summary>Obtener proveedor por ID</summary>
    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetById(int id)
    {
        try { return Ok(await _service.GetByIdAsync(id)); }
        catch (KeyNotFoundException ex) { return NotFound(new { mensaje = ex.Message }); }
    }

    /// <summary>Registrar proveedor</summary>
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CrearProveedorDto dto)
    {
        try
        {
            var result = await _service.CreateAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = result.Id }, result);
        }
        catch (InvalidOperationException ex) { return Conflict(new { mensaje = ex.Message }); }
    }

    /// <summary>Actualizar proveedor</summary>
    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, [FromBody] ActualizarProveedorDto dto)
    {
        try { return Ok(await _service.UpdateAsync(id, dto)); }
        catch (KeyNotFoundException ex) { return NotFound(new { mensaje = ex.Message }); }
    }
}

[Authorize(Roles = "Administrador")]
public class OrdenesCompraController : BaseController
{
    private readonly IOrdenCompraService _service;
    public OrdenesCompraController(IOrdenCompraService service) => _service = service;

    /// <summary>Listar todas las órdenes de compra</summary>
    [HttpGet]
    public async Task<IActionResult> GetAll() => Ok(await _service.GetAllAsync());

    /// <summary>Filtrar órdenes por proveedor</summary>
    [HttpGet("proveedor/{proveedorId:int}")]
    public async Task<IActionResult> GetByProveedor(int proveedorId) =>
        Ok(await _service.GetByProveedorAsync(proveedorId));

    /// <summary>Filtrar órdenes por rango de fechas</summary>
    [HttpGet("historial")]
    public async Task<IActionResult> GetByFecha([FromQuery] DateTime desde, [FromQuery] DateTime hasta) =>
        Ok(await _service.GetByFechaAsync(desde, hasta));

    /// <summary>Obtener detalle de una orden</summary>
    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetById(int id)
    {
        try { return Ok(await _service.GetByIdAsync(id)); }
        catch (KeyNotFoundException ex) { return NotFound(new { mensaje = ex.Message }); }
    }

    /// <summary>Registrar nueva orden de compra</summary>
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CrearOrdenCompraDto dto)
    {
        try
        {
            var result = await _service.CreateAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = result.Id }, result);
        }
        catch (InvalidOperationException ex) { return BadRequest(new { mensaje = ex.Message }); }
        catch (KeyNotFoundException ex) { return NotFound(new { mensaje = ex.Message }); }
    }

    /// <summary>Editar orden de compra pendiente</summary>
    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, [FromBody] ActualizarOrdenCompraDto dto)
    {
        try { return Ok(await _service.UpdateAsync(id, dto)); }
        catch (InvalidOperationException ex) { return BadRequest(new { mensaje = ex.Message }); }
        catch (KeyNotFoundException ex) { return NotFound(new { mensaje = ex.Message }); }
    }

    /// <summary>Confirmar recepción de productos</summary>
    [HttpPatch("{id:int}/confirmar-recepcion")]
    public async Task<IActionResult> ConfirmarRecepcion(int id)
    {
        try
        {
            await _service.ConfirmarRecepcionAsync(id);
            return Ok(new { mensaje = "Recepción confirmada. Inventario actualizado." });
        }
        catch (InvalidOperationException ex) { return BadRequest(new { mensaje = ex.Message }); }
        catch (KeyNotFoundException ex) { return NotFound(new { mensaje = ex.Message }); }
    }

    /// <summary>Cancelar orden de compra</summary>
    [HttpPatch("{id:int}/cancelar")]
    public async Task<IActionResult> Cancelar(int id)
    {
        try
        {
            await _service.CancelarAsync(id);
            return Ok(new { mensaje = "Orden cancelada correctamente." });
        }
        catch (InvalidOperationException ex) { return BadRequest(new { mensaje = ex.Message }); }
        catch (KeyNotFoundException ex) { return NotFound(new { mensaje = ex.Message }); }
    }

    /// <summary>Eliminar orden de compra</summary>
    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        try
        {
            await _service.DeleteAsync(id);
            return Ok(new { mensaje = "Orden eliminada correctamente." });
        }
        catch (KeyNotFoundException ex) { return NotFound(new { mensaje = ex.Message }); }
    }
}
