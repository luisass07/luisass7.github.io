using AsaderoERP.Domain.Entities;
using AsaderoERP.Domain.Enums;
using AsaderoERP.Domain.Interfaces;
using AsaderoERP.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace AsaderoERP.Infrastructure.Repositories;

// ─── PROVEEDOR ───────────────────────────────────────────────────────────────
public class ProveedorRepository : IProveedorRepository
{
    private readonly AsaderoDbContext _db;
    public ProveedorRepository(AsaderoDbContext db) => _db = db;

    public async Task<IEnumerable<Proveedor>> GetAllAsync() =>
        await _db.Proveedores.Where(p => p.Activo).ToListAsync();

    public async Task<Proveedor?> GetByIdAsync(int id) =>
        await _db.Proveedores.FindAsync(id);

    public async Task<Proveedor?> GetByNitAsync(string nit) =>
        await _db.Proveedores.FirstOrDefaultAsync(p => p.Nit == nit);

    public async Task<Proveedor> CreateAsync(Proveedor p)
    {
        _db.Proveedores.Add(p);
        await _db.SaveChangesAsync();
        return p;
    }

    public async Task<Proveedor> UpdateAsync(Proveedor p)
    {
        _db.Proveedores.Update(p);
        await _db.SaveChangesAsync();
        return p;
    }

    public async Task<bool> ExistsAsync(int id) =>
        await _db.Proveedores.AnyAsync(p => p.Id == id);
}

// ─── ORDEN COMPRA ────────────────────────────────────────────────────────────
public class OrdenCompraRepository : IOrdenCompraRepository
{
    private readonly AsaderoDbContext _db;
    public OrdenCompraRepository(AsaderoDbContext db) => _db = db;

    public async Task<IEnumerable<OrdenCompra>> GetAllAsync() =>
        await _db.OrdenesCompra.Include(o => o.Proveedor).Include(o => o.Detalles)
            .ThenInclude(d => d.Producto).OrderByDescending(o => o.FechaCreacion).ToListAsync();

    public async Task<IEnumerable<OrdenCompra>> GetByProveedorAsync(int proveedorId) =>
        await _db.OrdenesCompra.Include(o => o.Proveedor).Include(o => o.Detalles)
            .ThenInclude(d => d.Producto).Where(o => o.ProveedorId == proveedorId).ToListAsync();

    public async Task<IEnumerable<OrdenCompra>> GetByFechaAsync(DateTime desde, DateTime hasta) =>
        await _db.OrdenesCompra.Include(o => o.Proveedor).Include(o => o.Detalles)
            .ThenInclude(d => d.Producto)
            .Where(o => o.FechaCreacion >= desde && o.FechaCreacion <= hasta).ToListAsync();

    public async Task<OrdenCompra?> GetByIdWithDetallesAsync(int id) =>
        await _db.OrdenesCompra.Include(o => o.Proveedor)
            .Include(o => o.Detalles).ThenInclude(d => d.Producto)
            .FirstOrDefaultAsync(o => o.Id == id);

    public async Task<OrdenCompra> CreateAsync(OrdenCompra o)
    {
        _db.OrdenesCompra.Add(o);
        await _db.SaveChangesAsync();
        return o;
    }

    public async Task<OrdenCompra> UpdateAsync(OrdenCompra o)
    {
        _db.OrdenesCompra.Update(o);
        await _db.SaveChangesAsync();
        return o;
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var o = await _db.OrdenesCompra.FindAsync(id);
        if (o == null) return false;
        _db.OrdenesCompra.Remove(o);
        await _db.SaveChangesAsync();
        return true;
    }

    public async Task<bool> ExistsAsync(int id) =>
        await _db.OrdenesCompra.AnyAsync(o => o.Id == id);
}

// ─── PRODUCTO ─────────────────────────────────────────────────────────────────
public class ProductoRepository : IProductoRepository
{
    private readonly AsaderoDbContext _db;
    public ProductoRepository(AsaderoDbContext db) => _db = db;

    public async Task<IEnumerable<Producto>> GetAllAsync() =>
        await _db.Productos.Where(p => p.Activo).ToListAsync();

    public async Task<IEnumerable<Producto>> GetBajoStockAsync() =>
        await _db.Productos.Where(p => p.Activo && p.StockActual <= p.StockMinimo).ToListAsync();

    public async Task<Producto?> GetByIdAsync(int id) =>
        await _db.Productos.FindAsync(id);

    public async Task<Producto> CreateAsync(Producto p)
    {
        _db.Productos.Add(p);
        await _db.SaveChangesAsync();
        return p;
    }

    public async Task<Producto> UpdateAsync(Producto p)
    {
        _db.Productos.Update(p);
        await _db.SaveChangesAsync();
        return p;
    }

    public async Task<bool> ExistsAsync(int id) =>
        await _db.Productos.AnyAsync(p => p.Id == id);
}

// ─── MOVIMIENTO INVENTARIO ───────────────────────────────────────────────────
public class MovimientoInventarioRepository : IMovimientoInventarioRepository
{
    private readonly AsaderoDbContext _db;
    public MovimientoInventarioRepository(AsaderoDbContext db) => _db = db;

    public async Task<IEnumerable<MovimientoInventario>> GetByProductoAsync(int productoId) =>
        await _db.MovimientosInventario.Include(m => m.Producto)
            .Where(m => m.ProductoId == productoId).OrderByDescending(m => m.Fecha).ToListAsync();

    public async Task<IEnumerable<MovimientoInventario>> GetAllAsync() =>
        await _db.MovimientosInventario.Include(m => m.Producto)
            .OrderByDescending(m => m.Fecha).ToListAsync();

    public async Task<MovimientoInventario> CreateAsync(MovimientoInventario m)
    {
        _db.MovimientosInventario.Add(m);
        await _db.SaveChangesAsync();
        return m;
    }
}

// ─── FACTURA ─────────────────────────────────────────────────────────────────
public class FacturaRepository : IFacturaRepository
{
    private readonly AsaderoDbContext _db;
    public FacturaRepository(AsaderoDbContext db) => _db = db;

    public async Task<IEnumerable<Factura>> GetAllAsync() =>
        await _db.Facturas.Include(f => f.Cliente).Include(f => f.Detalles)
            .ThenInclude(d => d.Producto).OrderByDescending(f => f.FechaEmision).ToListAsync();

    public async Task<IEnumerable<Factura>> GetByFechaAsync(DateTime desde, DateTime hasta) =>
        await _db.Facturas.Include(f => f.Cliente).Include(f => f.Detalles)
            .ThenInclude(d => d.Producto)
            .Where(f => f.FechaEmision >= desde && f.FechaEmision <= hasta).ToListAsync();

    public async Task<Factura?> GetByIdWithDetallesAsync(int id) =>
        await _db.Facturas.Include(f => f.Cliente).Include(f => f.Usuario)
            .Include(f => f.Detalles).ThenInclude(d => d.Producto)
            .FirstOrDefaultAsync(f => f.Id == id);

    public async Task<Factura?> GetByNumeroAsync(string numero) =>
        await _db.Facturas.Include(f => f.Detalles).ThenInclude(d => d.Producto)
            .FirstOrDefaultAsync(f => f.NumeroFactura == numero);

    public async Task<Factura> CreateAsync(Factura f)
    {
        _db.Facturas.Add(f);
        await _db.SaveChangesAsync();
        return f;
    }

    public async Task<Factura> UpdateAsync(Factura f)
    {
        _db.Facturas.Update(f);
        await _db.SaveChangesAsync();
        return f;
    }

    public async Task<string> GenerarNumeroFacturaAsync()
    {
        var ultimo = await _db.Facturas.OrderByDescending(f => f.Id).Select(f => f.Id).FirstOrDefaultAsync();
        return $"FAC-{DateTime.UtcNow.Year}-{(ultimo + 1):D6}";
    }

    public async Task<decimal> GetTotalVentasDiaAsync(DateTime fecha)
    {
        var inicio = fecha.Date;
        var fin = inicio.AddDays(1);
        return await _db.Facturas
            .Where(f => f.FechaEmision >= inicio && f.FechaEmision < fin && f.Estado != EstadoFactura.Anulada)
            .SumAsync(f => f.Total);
    }

    public async Task<decimal> GetTotalVentasMesAsync(int anio, int mes) =>
        await _db.Facturas
            .Where(f => f.FechaEmision.Year == anio && f.FechaEmision.Month == mes && f.Estado != EstadoFactura.Anulada)
            .SumAsync(f => f.Total);

    public async Task<Producto?> GetProductoMasVendidoAsync() =>
        await _db.DetallesFactura
            .Include(d => d.Producto)
            .Where(d => d.Factura.Estado != EstadoFactura.Anulada)
            .GroupBy(d => d.ProductoId)
            .OrderByDescending(g => g.Sum(d => d.Cantidad))
            .Select(g => g.First().Producto)
            .FirstOrDefaultAsync();
}

// ─── ACTIVO FIJO ─────────────────────────────────────────────────────────────
public class ActivoFijoRepository : IActivoFijoRepository
{
    private readonly AsaderoDbContext _db;
    public ActivoFijoRepository(AsaderoDbContext db) => _db = db;

    public async Task<IEnumerable<ActivoFijo>> GetAllAsync() =>
        await _db.ActivosFijos.ToListAsync();

    public async Task<ActivoFijo?> GetByIdAsync(int id) =>
        await _db.ActivosFijos.FindAsync(id);

    public async Task<ActivoFijo> CreateAsync(ActivoFijo a)
    {
        _db.ActivosFijos.Add(a);
        await _db.SaveChangesAsync();
        return a;
    }

    public async Task<ActivoFijo> UpdateAsync(ActivoFijo a)
    {
        _db.ActivosFijos.Update(a);
        await _db.SaveChangesAsync();
        return a;
    }

    public async Task<bool> ExistsAsync(int id) =>
        await _db.ActivosFijos.AnyAsync(a => a.Id == id);
}

// ─── EMPLEADO ────────────────────────────────────────────────────────────────
public class EmpleadoRepository : IEmpleadoRepository
{
    private readonly AsaderoDbContext _db;
    public EmpleadoRepository(AsaderoDbContext db) => _db = db;

    public async Task<IEnumerable<Empleado>> GetAllAsync() =>
        await _db.Empleados.Where(e => e.Activo).ToListAsync();

    public async Task<Empleado?> GetByIdAsync(int id) =>
        await _db.Empleados.FindAsync(id);

    public async Task<Empleado?> GetByCedulaAsync(string cedula) =>
        await _db.Empleados.FirstOrDefaultAsync(e => e.Cedula == cedula);

    public async Task<Empleado> CreateAsync(Empleado e)
    {
        _db.Empleados.Add(e);
        await _db.SaveChangesAsync();
        return e;
    }

    public async Task<Empleado> UpdateAsync(Empleado e)
    {
        _db.Empleados.Update(e);
        await _db.SaveChangesAsync();
        return e;
    }

    public async Task<bool> ExistsAsync(int id) =>
        await _db.Empleados.AnyAsync(e => e.Id == id);
}

// ─── ASISTENCIA ──────────────────────────────────────────────────────────────
public class AsistenciaRepository : IAsistenciaRepository
{
    private readonly AsaderoDbContext _db;
    public AsistenciaRepository(AsaderoDbContext db) => _db = db;

    public async Task<IEnumerable<Asistencia>> GetByEmpleadoAsync(int empleadoId) =>
        await _db.Asistencias.Where(a => a.EmpleadoId == empleadoId)
            .OrderByDescending(a => a.FechaEntrada).ToListAsync();

    public async Task<IEnumerable<Asistencia>> GetByPeriodoAsync(int empleadoId, DateTime desde, DateTime hasta) =>
        await _db.Asistencias
            .Where(a => a.EmpleadoId == empleadoId && a.FechaEntrada >= desde && a.FechaEntrada <= hasta)
            .ToListAsync();

    public async Task<Asistencia> CreateAsync(Asistencia a)
    {
        _db.Asistencias.Add(a);
        await _db.SaveChangesAsync();
        return a;
    }

    public async Task<Asistencia> UpdateAsync(Asistencia a)
    {
        _db.Asistencias.Update(a);
        await _db.SaveChangesAsync();
        return a;
    }

    public async Task<Asistencia?> GetByIdAsync(int id) =>
        await _db.Asistencias.FindAsync(id);
}

// ─── USUARIO ─────────────────────────────────────────────────────────────────
public class UsuarioRepository : IUsuarioRepository
{
    private readonly AsaderoDbContext _db;
    public UsuarioRepository(AsaderoDbContext db) => _db = db;

    public async Task<Usuario?> GetByEmailAsync(string email) =>
        await _db.Usuarios.FirstOrDefaultAsync(u => u.Email == email);

    public async Task<Usuario?> GetByIdAsync(int id) =>
        await _db.Usuarios.FindAsync(id);

    public async Task<Usuario> CreateAsync(Usuario u)
    {
        _db.Usuarios.Add(u);
        await _db.SaveChangesAsync();
        return u;
    }

    public async Task<Usuario> UpdateAsync(Usuario u)
    {
        _db.Usuarios.Update(u);
        await _db.SaveChangesAsync();
        return u;
    }

    public async Task<bool> ExistsAsync(string email) =>
        await _db.Usuarios.AnyAsync(u => u.Email == email);
}
