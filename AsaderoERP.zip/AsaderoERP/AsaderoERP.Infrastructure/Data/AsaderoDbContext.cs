using AsaderoERP.Domain.Entities;
using AsaderoERP.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace AsaderoERP.Infrastructure.Data;

public class AsaderoDbContext : DbContext
{
    public AsaderoDbContext(DbContextOptions<AsaderoDbContext> options) : base(options) { }

    public DbSet<Usuario> Usuarios => Set<Usuario>();
    public DbSet<Proveedor> Proveedores => Set<Proveedor>();
    public DbSet<OrdenCompra> OrdenesCompra => Set<OrdenCompra>();
    public DbSet<DetalleOrdenCompra> DetallesOrdenCompra => Set<DetalleOrdenCompra>();
    public DbSet<HistorialEstadoOrden> HistorialEstadoOrden => Set<HistorialEstadoOrden>();
    public DbSet<Producto> Productos => Set<Producto>();
    public DbSet<MovimientoInventario> MovimientosInventario => Set<MovimientoInventario>();
    public DbSet<Cliente> Clientes => Set<Cliente>();
    public DbSet<Factura> Facturas => Set<Factura>();
    public DbSet<DetalleFactura> DetallesFactura => Set<DetalleFactura>();
    public DbSet<ActivoFijo> ActivosFijos => Set<ActivoFijo>();
    public DbSet<Empleado> Empleados => Set<Empleado>();
    public DbSet<Asistencia> Asistencias => Set<Asistencia>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // ── Usuario ─────────────────────────────────────────────────────────
        modelBuilder.Entity<Usuario>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Nombre).IsRequired().HasMaxLength(100);
            e.Property(x => x.Email).IsRequired().HasMaxLength(150);
            e.HasIndex(x => x.Email).IsUnique();
            e.Property(x => x.PasswordHash).IsRequired();
            e.Property(x => x.Rol).HasConversion<string>();
        });

        // ── Proveedor ────────────────────────────────────────────────────────
        modelBuilder.Entity<Proveedor>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Nombre).IsRequired().HasMaxLength(150);
            e.Property(x => x.Nit).IsRequired().HasMaxLength(20);
            e.HasIndex(x => x.Nit).IsUnique();
            e.Property(x => x.Email).HasMaxLength(150);
            e.Property(x => x.Telefono).HasMaxLength(20);
            e.Property(x => x.Direccion).HasMaxLength(250);
        });

        // ── OrdenCompra ──────────────────────────────────────────────────────
        modelBuilder.Entity<OrdenCompra>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Total).HasColumnType("decimal(18,2)");
            e.Property(x => x.Estado).HasConversion<string>();
            e.HasOne(x => x.Proveedor).WithMany(p => p.OrdenesCompra)
                .HasForeignKey(x => x.ProveedorId).OnDelete(DeleteBehavior.Restrict);
            e.HasMany(x => x.Detalles).WithOne(d => d.OrdenCompra)
                .HasForeignKey(d => d.OrdenCompraId).OnDelete(DeleteBehavior.Cascade);
            e.HasMany(x => x.Historial).WithOne(h => h.OrdenCompra)
                .HasForeignKey(h => h.OrdenCompraId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<DetalleOrdenCompra>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Cantidad).HasColumnType("decimal(18,3)");
            e.Property(x => x.PrecioUnitario).HasColumnType("decimal(18,2)");
            e.Ignore(x => x.Subtotal);
            e.HasOne(x => x.Producto).WithMany(p => p.DetallesOrdenCompra)
                .HasForeignKey(x => x.ProductoId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<HistorialEstadoOrden>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.EstadoAnterior).HasConversion<string>();
            e.Property(x => x.EstadoNuevo).HasConversion<string>();
        });

        // ── Producto ─────────────────────────────────────────────────────────
        modelBuilder.Entity<Producto>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Nombre).IsRequired().HasMaxLength(150);
            e.Property(x => x.Categoria).IsRequired().HasMaxLength(100);
            e.Property(x => x.PrecioVenta).HasColumnType("decimal(18,2)");
            e.Property(x => x.CostoPromedio).HasColumnType("decimal(18,2)");
            e.Property(x => x.StockActual).HasColumnType("decimal(18,3)");
            e.Property(x => x.StockMinimo).HasColumnType("decimal(18,3)");
            e.Property(x => x.UnidadMedida).HasMaxLength(30);
        });

        // ── MovimientoInventario ─────────────────────────────────────────────
        modelBuilder.Entity<MovimientoInventario>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Tipo).HasConversion<string>();
            e.Property(x => x.Cantidad).HasColumnType("decimal(18,3)");
            e.Property(x => x.StockAnterior).HasColumnType("decimal(18,3)");
            e.Property(x => x.StockNuevo).HasColumnType("decimal(18,3)");
            e.Property(x => x.Referencia).HasMaxLength(50);
            e.HasOne(x => x.Producto).WithMany(p => p.Movimientos)
                .HasForeignKey(x => x.ProductoId).OnDelete(DeleteBehavior.Restrict);
        });

        // ── Cliente ──────────────────────────────────────────────────────────
        modelBuilder.Entity<Cliente>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Nombre).IsRequired().HasMaxLength(150);
            e.Property(x => x.Email).HasMaxLength(150);
            e.Property(x => x.Nit).HasMaxLength(20);
        });

        // ── Factura ──────────────────────────────────────────────────────────
        modelBuilder.Entity<Factura>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.NumeroFactura).IsRequired().HasMaxLength(30);
            e.HasIndex(x => x.NumeroFactura).IsUnique();
            e.Property(x => x.Subtotal).HasColumnType("decimal(18,2)");
            e.Property(x => x.Iva).HasColumnType("decimal(18,2)");
            e.Property(x => x.Total).HasColumnType("decimal(18,2)");
            e.Property(x => x.Estado).HasConversion<string>();
            e.HasOne(x => x.Cliente).WithMany(c => c.Facturas)
                .HasForeignKey(x => x.ClienteId).IsRequired(false).OnDelete(DeleteBehavior.SetNull);
            e.HasOne(x => x.Usuario).WithMany(u => u.Facturas)
                .HasForeignKey(x => x.UsuarioId).OnDelete(DeleteBehavior.Restrict);
            e.HasMany(x => x.Detalles).WithOne(d => d.Factura)
                .HasForeignKey(d => d.FacturaId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<DetalleFactura>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Cantidad).HasColumnType("decimal(18,3)");
            e.Property(x => x.PrecioUnitario).HasColumnType("decimal(18,2)");
            e.Ignore(x => x.Subtotal);
            e.HasOne(x => x.Producto).WithMany(p => p.DetallesFactura)
                .HasForeignKey(x => x.ProductoId).OnDelete(DeleteBehavior.Restrict);
        });

        // ── ActivoFijo ───────────────────────────────────────────────────────
        modelBuilder.Entity<ActivoFijo>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Nombre).IsRequired().HasMaxLength(150);
            e.Property(x => x.Categoria).IsRequired().HasMaxLength(100);
            e.Property(x => x.ValorCompra).HasColumnType("decimal(18,2)");
            e.Property(x => x.ValorActual).HasColumnType("decimal(18,2)");
            e.Property(x => x.DepreciacionAnual).HasColumnType("decimal(18,2)");
            e.Property(x => x.DepreciacionAcumulada).HasColumnType("decimal(18,2)");
            e.Property(x => x.Estado).HasConversion<string>();
            e.Property(x => x.NumeroSerie).HasMaxLength(100);
        });

        // ── Empleado ─────────────────────────────────────────────────────────
        modelBuilder.Entity<Empleado>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Nombre).IsRequired().HasMaxLength(100);
            e.Property(x => x.Apellido).IsRequired().HasMaxLength(100);
            e.Property(x => x.Cedula).IsRequired().HasMaxLength(20);
            e.HasIndex(x => x.Cedula).IsUnique();
            e.Property(x => x.Cargo).IsRequired().HasMaxLength(100);
            e.Property(x => x.SalarioBase).HasColumnType("decimal(18,2)");
            e.Ignore(x => x.NombreCompleto);
            e.HasMany(x => x.Asistencias).WithOne(a => a.Empleado)
                .HasForeignKey(a => a.EmpleadoId).OnDelete(DeleteBehavior.Cascade);
        });

        // ── Asistencia ───────────────────────────────────────────────────────
        modelBuilder.Entity<Asistencia>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.HorasTrabajadas).HasColumnType("decimal(8,2)");
        });

        // ── Seed inicial: usuario administrador ──────────────────────────────
        modelBuilder.Entity<Usuario>().HasData(new Usuario
        {
            Id = 1,
            Nombre = "Administrador",
            Email = "admin@asadero.com",
            PasswordHash = BCrypt.Net.BCrypt.HashPassword("Admin123!"),
            Rol = RolUsuario.Administrador,
            Activo = true,
            FechaCreacion = new DateTime(2024, 1, 1, 0, 0, 0, DateTimeKind.Utc)
        });
    }
}
