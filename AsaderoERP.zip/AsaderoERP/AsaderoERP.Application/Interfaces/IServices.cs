using AsaderoERP.Application.DTOs;

namespace AsaderoERP.Application.Interfaces;

public interface IProveedorService
{
    Task<IEnumerable<ProveedorDto>> GetAllAsync();
    Task<ProveedorDto> GetByIdAsync(int id);
    Task<ProveedorDto> CreateAsync(CrearProveedorDto dto);
    Task<ProveedorDto> UpdateAsync(int id, ActualizarProveedorDto dto);
}

public interface IOrdenCompraService
{
    Task<IEnumerable<OrdenCompraDto>> GetAllAsync();
    Task<IEnumerable<OrdenCompraDto>> GetByProveedorAsync(int proveedorId);
    Task<IEnumerable<OrdenCompraDto>> GetByFechaAsync(DateTime desde, DateTime hasta);
    Task<OrdenCompraDto> GetByIdAsync(int id);
    Task<OrdenCompraDto> CreateAsync(CrearOrdenCompraDto dto);
    Task<OrdenCompraDto> UpdateAsync(int id, ActualizarOrdenCompraDto dto);
    Task ConfirmarRecepcionAsync(int id);
    Task CancelarAsync(int id);
    Task DeleteAsync(int id);
}

public interface IProductoService
{
    Task<IEnumerable<ProductoDto>> GetAllAsync();
    Task<IEnumerable<ProductoDto>> GetBajoStockAsync();
    Task<ProductoDto> GetByIdAsync(int id);
    Task<ProductoDto> CreateAsync(CrearProductoDto dto);
    Task<ProductoDto> UpdateAsync(int id, ActualizarProductoDto dto);
    Task AjustarInventarioAsync(AjusteInventarioDto dto);
    Task<IEnumerable<object>> GetKardexAsync(int productoId);
    Task<decimal> GetCostoPromedioAsync(int productoId);
}

public interface IFacturaService
{
    Task<IEnumerable<FacturaDto>> GetAllAsync();
    Task<IEnumerable<FacturaDto>> GetByFechaAsync(DateTime desde, DateTime hasta);
    Task<FacturaDto> GetByIdAsync(int id);
    Task<FacturaDto> CreateAsync(CrearFacturaDto dto, int usuarioId);
    Task AnularAsync(int id, AnularFacturaDto dto);
    Task<decimal> GetTotalVentasDiaAsync(DateTime fecha);
    Task<decimal> GetTotalVentasMesAsync(int anio, int mes);
}

public interface IActivoFijoService
{
    Task<IEnumerable<ActivoFijoDto>> GetAllAsync();
    Task<ActivoFijoDto> GetByIdAsync(int id);
    Task<ActivoFijoDto> CreateAsync(CrearActivoFijoDto dto);
    Task<ActivoFijoDto> UpdateAsync(int id, ActualizarActivoFijoDto dto);
    Task DarDeBajaAsync(int id, DarDeBajaActivoDto dto);
}

public interface IEmpleadoService
{
    Task<IEnumerable<EmpleadoDto>> GetAllAsync();
    Task<EmpleadoDto> GetByIdAsync(int id);
    Task<EmpleadoDto> CreateAsync(CrearEmpleadoDto dto);
    Task<EmpleadoDto> UpdateAsync(int id, ActualizarEmpleadoDto dto);
    Task EliminarAsync(int id);
    Task<AsistenciaDto> RegistrarEntradaAsync(RegistrarAsistenciaDto dto);
    Task<AsistenciaDto> RegistrarSalidaAsync(int asistenciaId, RegistrarSalidaDto dto);
    Task<IEnumerable<AsistenciaDto>> GetAsistenciasAsync(int empleadoId);
    Task<NominaEmpleadoDto> CalcularNominaAsync(int empleadoId, DateTime desde, DateTime hasta);
}

public interface IEisService
{
    Task<DashboardDto> GetDashboardAsync();
    Task<decimal> GetVentasHoyAsync();
    Task<decimal> GetVentasMesAsync(int anio, int mes);
    Task<string?> GetProductoMasVendidoAsync();
    Task<decimal> GetGananciasAsync(DateTime desde, DateTime hasta);
    Task<IEnumerable<ProductoBajoStockDto>> GetProductosBajoStockAsync();
}

public interface IAuthService
{
    Task<AuthResponseDto> LoginAsync(LoginDto dto);
    Task<AuthResponseDto> RegisterAsync(RegisterDto dto);
}
