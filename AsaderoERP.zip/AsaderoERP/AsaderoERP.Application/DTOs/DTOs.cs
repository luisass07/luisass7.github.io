using AsaderoERP.Domain.Enums;

namespace AsaderoERP.Application.DTOs;

// ─── PROVEEDOR ──────────────────────────────────────────────────────────────
public record ProveedorDto(int Id, string Nombre, string Nit, string Telefono, string Email, string Direccion, bool Activo);
public record CrearProveedorDto(string Nombre, string Nit, string Telefono, string Email, string Direccion);
public record ActualizarProveedorDto(string Nombre, string Telefono, string Email, string Direccion);

// ─── ORDEN DE COMPRA ─────────────────────────────────────────────────────────
public record DetalleOrdenCompraDto(int ProductoId, string NombreProducto, decimal Cantidad, decimal PrecioUnitario, decimal Subtotal);
public record CrearDetalleOrdenDto(int ProductoId, decimal Cantidad, decimal PrecioUnitario);

public record OrdenCompraDto(
    int Id, int ProveedorId, string NombreProveedor,
    DateTime FechaCreacion, DateTime? FechaRecepcion,
    string Estado, decimal Total, string? Observaciones,
    IEnumerable<DetalleOrdenCompraDto> Detalles);

public record CrearOrdenCompraDto(
    int ProveedorId,
    string? Observaciones,
    IEnumerable<CrearDetalleOrdenDto> Detalles);

public record ActualizarOrdenCompraDto(
    string? Observaciones,
    IEnumerable<CrearDetalleOrdenDto> Detalles);

// ─── PRODUCTO ────────────────────────────────────────────────────────────────
public record ProductoDto(
    int Id, string Nombre, string Categoria, string? Descripcion,
    decimal PrecioVenta, decimal CostoPromedio, decimal StockActual,
    decimal StockMinimo, string UnidadMedida, bool Activo);

public record CrearProductoDto(
    string Nombre, string Categoria, string? Descripcion,
    decimal PrecioVenta, decimal StockMinimo, string UnidadMedida);

public record ActualizarProductoDto(
    string Nombre, string Categoria, string? Descripcion,
    decimal PrecioVenta, decimal StockMinimo, string UnidadMedida);

public record AjusteInventarioDto(int ProductoId, decimal NuevaCantidad, string Motivo);

// ─── FACTURA ─────────────────────────────────────────────────────────────────
public record DetalleFacturaDto(int ProductoId, string NombreProducto, decimal Cantidad, decimal PrecioUnitario, decimal Subtotal);
public record CrearDetalleFacturaDto(int ProductoId, decimal Cantidad, decimal PrecioUnitario);

public record FacturaDto(
    int Id, string NumeroFactura, int? ClienteId, string? NombreCliente,
    DateTime FechaEmision, decimal Subtotal, decimal Iva, decimal Total,
    string Estado, bool EnviadaDIAN, bool EnviadaCliente,
    IEnumerable<DetalleFacturaDto> Detalles);

public record CrearFacturaDto(
    int? ClienteId,
    IEnumerable<CrearDetalleFacturaDto> Detalles);

public record AnularFacturaDto(string Motivo);

// ─── CLIENTE ─────────────────────────────────────────────────────────────────
public record ClienteDto(int Id, string Nombre, string? Nit, string? Email, string? Telefono);
public record CrearClienteDto(string Nombre, string? Nit, string? Email, string? Telefono, string? Direccion);

// ─── ACTIVO FIJO ─────────────────────────────────────────────────────────────
public record ActivoFijoDto(
    int Id, string Nombre, string Categoria, string? Descripcion,
    decimal ValorCompra, decimal ValorActual, DateTime FechaAdquisicion,
    int VidaUtilAnios, decimal DepreciacionAnual, decimal DepreciacionAcumulada,
    string Estado, string? NumeroSerie);

public record CrearActivoFijoDto(
    string Nombre, string Categoria, string? Descripcion,
    decimal ValorCompra, DateTime FechaAdquisicion,
    int VidaUtilAnios, string? NumeroSerie);

public record ActualizarActivoFijoDto(
    string Nombre, string Categoria, string? Descripcion,
    decimal ValorCompra, int VidaUtilAnios, string? NumeroSerie);

public record DarDeBajaActivoDto(string Motivo);

// ─── EMPLEADO ────────────────────────────────────────────────────────────────
public record EmpleadoDto(
    int Id, string Nombre, string Apellido, string Cedula,
    string Cargo, string? Telefono, string? Email,
    decimal SalarioBase, DateTime FechaIngreso, bool Activo);

public record CrearEmpleadoDto(
    string Nombre, string Apellido, string Cedula,
    string Cargo, string? Telefono, string? Email,
    decimal SalarioBase, DateTime FechaIngreso);

public record ActualizarEmpleadoDto(
    string Nombre, string Apellido, string Cargo,
    string? Telefono, string? Email, decimal SalarioBase);

public record RegistrarAsistenciaDto(int EmpleadoId, DateTime FechaEntrada);
public record RegistrarSalidaDto(DateTime FechaSalida);

public record AsistenciaDto(
    int Id, int EmpleadoId, string NombreEmpleado,
    DateTime FechaEntrada, DateTime? FechaSalida,
    decimal HorasTrabajadas, string? Observaciones);

public record NominaEmpleadoDto(
    int EmpleadoId, string NombreEmpleado,
    decimal SalarioBase, decimal HorasTrabajadas,
    decimal SalarioCalculado, DateTime PeriodoDesde, DateTime PeriodoHasta);

// ─── AUTENTICACIÓN ───────────────────────────────────────────────────────────
public record LoginDto(string Email, string Password);
public record RegisterDto(string Nombre, string Email, string Password, string Rol);
public record AuthResponseDto(string Token, string Nombre, string Email, string Rol);

// ─── EIS / DASHBOARD ────────────────────────────────────────────────────────
public record DashboardDto(
    decimal VentasHoy, decimal VentasMes, decimal GananciaMes,
    int TotalProductosBajoStock, string? ProductoMasVendido,
    int TotalEmpleados, int TotalActivosFijos);

public record VentasMensualesDto(int Anio, int Mes, decimal Total);

public record ProductoBajoStockDto(int Id, string Nombre, decimal StockActual, decimal StockMinimo);
