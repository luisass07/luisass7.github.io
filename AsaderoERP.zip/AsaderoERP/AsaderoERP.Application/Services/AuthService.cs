using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using AsaderoERP.Application.DTOs;
using AsaderoERP.Application.Interfaces;
using AsaderoERP.Domain.Entities;
using AsaderoERP.Domain.Enums;
using AsaderoERP.Domain.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace AsaderoERP.Application.Services;

public class AuthService : IAuthService
{
    private readonly IUsuarioRepository _usuarioRepo;
    private readonly IConfiguration _config;

    public AuthService(IUsuarioRepository usuarioRepo, IConfiguration config)
    {
        _usuarioRepo = usuarioRepo;
        _config = config;
    }

    public async Task<AuthResponseDto> LoginAsync(LoginDto dto)
    {
        var usuario = await _usuarioRepo.GetByEmailAsync(dto.Email)
            ?? throw new UnauthorizedAccessException("Credenciales inválidas.");

        if (!BCrypt.Net.BCrypt.Verify(dto.Password, usuario.PasswordHash))
            throw new UnauthorizedAccessException("Credenciales inválidas.");

        if (!usuario.Activo)
            throw new UnauthorizedAccessException("Usuario inactivo.");

        usuario.UltimoAcceso = DateTime.UtcNow;
        await _usuarioRepo.UpdateAsync(usuario);

        var token = GenerarToken(usuario);
        return new AuthResponseDto(token, usuario.Nombre, usuario.Email, usuario.Rol.ToString());
    }

    public async Task<AuthResponseDto> RegisterAsync(RegisterDto dto)
    {
        if (await _usuarioRepo.ExistsAsync(dto.Email))
            throw new InvalidOperationException($"Ya existe un usuario con email {dto.Email}.");

        if (!Enum.TryParse<RolUsuario>(dto.Rol, true, out var rol))
            throw new ArgumentException($"Rol inválido: {dto.Rol}. Válidos: Administrador, Cajero, Gerente.");

        var usuario = new Usuario
        {
            Nombre = dto.Nombre,
            Email = dto.Email,
            PasswordHash = BCrypt.Net.BCrypt.HashPassword(dto.Password),
            Rol = rol
        };

        var creado = await _usuarioRepo.CreateAsync(usuario);
        var token = GenerarToken(creado);
        return new AuthResponseDto(token, creado.Nombre, creado.Email, creado.Rol.ToString());
    }

    private string GenerarToken(Usuario usuario)
    {
        var jwtSettings = _config.GetSection("JwtSettings");
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSettings["SecretKey"]!));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        var claims = new[]
        {
            new Claim(ClaimTypes.NameIdentifier, usuario.Id.ToString()),
            new Claim(ClaimTypes.Name, usuario.Nombre),
            new Claim(ClaimTypes.Email, usuario.Email),
            new Claim(ClaimTypes.Role, usuario.Rol.ToString())
        };

        var token = new JwtSecurityToken(
            issuer: jwtSettings["Issuer"],
            audience: jwtSettings["Audience"],
            claims: claims,
            expires: DateTime.UtcNow.AddHours(8),
            signingCredentials: creds);

        return new JwtSecurityTokenHandler().WriteToken(token);
    }
}
