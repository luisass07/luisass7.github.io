using AsaderoERP.Application.DTOs;
using AsaderoERP.Application.Interfaces;
using AsaderoERP.Domain.Entities;
using AsaderoERP.Domain.Enums;
using AsaderoERP.Domain.Interfaces;

namespace AsaderoERP.Application.Services;

public class ProveedorService : IProveedorService
{
    private readonly IProveedorRepository _repo;

    public ProveedorService(IProveedorRepository repo) => _repo = repo;

    public async Task<IEnumerable<ProveedorDto>> GetAllAsync()
    {
        var proveedores = await _repo.GetAllAsync();
        return proveedores.Select(MapToDto);
    }

    public async Task<ProveedorDto> GetByIdAsync(int id)
    {
        var p = await _repo.GetByIdAsync(id)
            ?? throw new KeyNotFoundException($"Proveedor con ID {id} no encontrado.");
        return MapToDto(p);
    }

    public async Task<ProveedorDto> CreateAsync(CrearProveedorDto dto)
    {
        var existente = await _repo.GetByNitAsync(dto.Nit);
        if (existente != null)
            throw new InvalidOperationException($"Ya existe un proveedor con NIT {dto.Nit}.");

        var proveedor = new Proveedor
        {
            Nombre = dto.Nombre,
            Nit = dto.Nit,
            Telefono = dto.Telefono,
            Email = dto.Email,
            Direccion = dto.Direccion
        };

        var creado = await _repo.CreateAsync(proveedor);
        return MapToDto(creado);
    }

    public async Task<ProveedorDto> UpdateAsync(int id, ActualizarProveedorDto dto)
    {
        var proveedor = await _repo.GetByIdAsync(id)
            ?? throw new KeyNotFoundException($"Proveedor con ID {id} no encontrado.");

        proveedor.Nombre = dto.Nombre;
        proveedor.Telefono = dto.Telefono;
        proveedor.Email = dto.Email;
        proveedor.Direccion = dto.Direccion;

        var actualizado = await _repo.UpdateAsync(proveedor);
        return MapToDto(actualizado);
    }

    private static ProveedorDto MapToDto(Proveedor p) =>
        new(p.Id, p.Nombre, p.Nit, p.Telefono, p.Email, p.Direccion, p.Activo);
}

public class OrdenCompraService : IOrdenCompraService
{
    private readonly IOrdenCompraRepository _ordenRepo;
    private readonly IProveedorRepository _proveedorRepo;
    private readonly IProductoRepository _productoRepo;
    private readonly IMovimientoInventarioRepository _movRepo;

    public OrdenCompraService(
        IOrdenCompraRepository ordenRepo,
        IProveedorRepository proveedorRepo,
        IProductoRepository productoRepo,
        IMovimientoInventarioRepository movRepo)
    {
        _ordenRepo = ordenRepo;
        _proveedorRepo = proveedorRepo;
        _productoRepo = productoRepo;
        _movRepo = movRepo;
    }

    public async Task<IEnumerable<OrdenCompraDto>> GetAllAsync()
    {
        var ordenes = await _ordenRepo.GetAllAsync();
        return ordenes.Select(MapToDto);
    }

    public async Task<IEnumerable<OrdenCompraDto>> GetByProveedorAsync(int proveedorId)
    {
        var ordenes = await _ordenRepo.GetByProveedorAsync(proveedorId);
        return ordenes.Select(MapToDto);
    }

    public async Task<IEnumerable<OrdenCompraDto>> GetByFechaAsync(DateTime desde, DateTime hasta)
    {
        var ordenes = await _ordenRepo.GetByFechaAsync(desde, hasta);
        return ordenes.Select(MapToDto);
    }

    public async Task<OrdenCompraDto> GetByIdAsync(int id)
    {
        var orden = await _ordenRepo.GetByIdWithDetallesAsync(id)
            ?? throw new KeyNotFoundException($"Orden de compra {id} no encontrada.");
        return MapToDto(orden);
    }

    public async Task<OrdenCompraDto> CreateAsync(CrearOrdenCompraDto dto)
    {
        if (!dto.Detalles.Any())
            throw new InvalidOperationException("La orden debe tener al menos un producto.");

        var proveedor = await _proveedorRepo.GetByIdAsync(dto.ProveedorId)
            ?? throw new KeyNotFoundException($"Proveedor {dto.ProveedorId} no encontrado.");

        var detalles = new List<DetalleOrdenCompra>();
        foreach (var d in dto.Detalles)
        {
            var producto = await _productoRepo.GetByIdAsync(d.ProductoId)
                ?? throw new KeyNotFoundException($"Producto {d.ProductoId} no encontrado.");
            detalles.Add(new DetalleOrdenCompra
            {
                ProductoId = d.ProductoId,
                Cantidad = d.Cantidad,
                PrecioUnitario = d.PrecioUnitario
            });
        }

        var orden = new OrdenCompra
        {
            ProveedorId = dto.ProveedorId,
            Observaciones = dto.Observaciones,
            Detalles = detalles,
            Total = detalles.Sum(d => d.Cantidad * d.PrecioUnitario)
        };

        var creada = await _ordenRepo.CreateAsync(orden);
        return MapToDto(creada);
    }

    public async Task<OrdenCompraDto> UpdateAsync(int id, ActualizarOrdenCompraDto dto)
    {
        var orden = await _ordenRepo.GetByIdWithDetallesAsync(id)
            ?? throw new KeyNotFoundException($"Orden {id} no encontrada.");

        if (orden.Estado != EstadoOrdenCompra.Pendiente)
            throw new InvalidOperationException("Solo se pueden editar órdenes en estado Pendiente.");

        if (!dto.Detalles.Any())
            throw new InvalidOperationException("La orden debe tener al menos un producto.");

        orden.Observaciones = dto.Observaciones;
        orden.Detalles.Clear();

        foreach (var d in dto.Detalles)
            orden.Detalles.Add(new DetalleOrdenCompra
            {
                OrdenCompraId = id,
                ProductoId = d.ProductoId,
                Cantidad = d.Cantidad,
                PrecioUnitario = d.PrecioUnitario
            });

        orden.Total = orden.Detalles.Sum(d => d.Cantidad * d.PrecioUnitario);

        var actualizada = await _ordenRepo.UpdateAsync(orden);
        return MapToDto(actualizada);
    }

    public async Task ConfirmarRecepcionAsync(int id)
    {
        var orden = await _ordenRepo.GetByIdWithDetallesAsync(id)
            ?? throw new KeyNotFoundException($"Orden {id} no encontrada.");

        if (orden.Estado == EstadoOrdenCompra.Cancelada)
            throw new InvalidOperationException("No se puede confirmar una orden cancelada.");

        if (orden.Estado == EstadoOrdenCompra.Recibida)
            throw new InvalidOperationException("La orden ya fue recibida.");

        // Actualizar stock de cada producto
        foreach (var detalle in orden.Detalles)
        {
            var producto = await _productoRepo.GetByIdAsync(detalle.ProductoId)
                ?? throw new KeyNotFoundException($"Producto {detalle.ProductoId} no encontrado.");

            var stockAnterior = producto.StockActual;
            producto.StockActual += detalle.Cantidad;

            // Recalcular costo promedio
            var totalCosto = (producto.CostoPromedio * stockAnterior) + (detalle.PrecioUnitario * detalle.Cantidad);
            producto.CostoPromedio = producto.StockActual > 0 ? totalCosto / producto.StockActual : detalle.PrecioUnitario;

            await _productoRepo.UpdateAsync(producto);

            await _movRepo.CreateAsync(new MovimientoInventario
            {
                ProductoId = detalle.ProductoId,
                Tipo = TipoMovimientoInventario.Entrada,
                Cantidad = detalle.Cantidad,
                StockAnterior = stockAnterior,
                StockNuevo = producto.StockActual,
                Referencia = $"OC-{id}",
                Motivo = "Recepción de orden de compra",
                OrdenCompraId = id
            });
        }

        orden.Estado = EstadoOrdenCompra.Recibida;
        orden.FechaRecepcion = DateTime.UtcNow;
        await _ordenRepo.UpdateAsync(orden);
    }

    public async Task CancelarAsync(int id)
    {
        var orden = await _ordenRepo.GetByIdWithDetallesAsync(id)
            ?? throw new KeyNotFoundException($"Orden {id} no encontrada.");

        if (orden.Estado == EstadoOrdenCompra.Recibida)
            throw new InvalidOperationException("No se puede cancelar una orden ya recibida.");

        orden.Estado = EstadoOrdenCompra.Cancelada;
        await _ordenRepo.UpdateAsync(orden);
    }

    public async Task DeleteAsync(int id)
    {
        if (!await _ordenRepo.ExistsAsync(id))
            throw new KeyNotFoundException($"Orden {id} no encontrada.");

        await _ordenRepo.DeleteAsync(id);
    }

    private static OrdenCompraDto MapToDto(OrdenCompra o) => new(
        o.Id, o.ProveedorId, o.Proveedor?.Nombre ?? string.Empty,
        o.FechaCreacion, o.FechaRecepcion,
        o.Estado.ToString(), o.Total, o.Observaciones,
        o.Detalles.Select(d => new DetalleOrdenCompraDto(
            d.ProductoId, d.Producto?.Nombre ?? string.Empty,
            d.Cantidad, d.PrecioUnitario, d.Subtotal)));
}
