using AsaderoERP.Application.DTOs;
using AsaderoERP.Application.Interfaces;
using AsaderoERP.Domain.Entities;
using AsaderoERP.Domain.Enums;
using AsaderoERP.Domain.Interfaces;

namespace AsaderoERP.Application.Services;

public class FacturaService : IFacturaService
{
    private readonly IFacturaRepository _facturaRepo;
    private readonly IProductoRepository _productoRepo;
    private readonly IMovimientoInventarioRepository _movRepo;
    private const decimal TASA_IVA = 0.19m;

    public FacturaService(
        IFacturaRepository facturaRepo,
        IProductoRepository productoRepo,
        IMovimientoInventarioRepository movRepo)
    {
        _facturaRepo = facturaRepo;
        _productoRepo = productoRepo;
        _movRepo = movRepo;
    }

    public async Task<IEnumerable<FacturaDto>> GetAllAsync()
    {
        var facturas = await _facturaRepo.GetAllAsync();
        return facturas.Select(MapToDto);
    }

    public async Task<IEnumerable<FacturaDto>> GetByFechaAsync(DateTime desde, DateTime hasta)
    {
        var facturas = await _facturaRepo.GetByFechaAsync(desde, hasta);
        return facturas.Select(MapToDto);
    }

    public async Task<FacturaDto> GetByIdAsync(int id)
    {
        var f = await _facturaRepo.GetByIdWithDetallesAsync(id)
            ?? throw new KeyNotFoundException($"Factura {id} no encontrada.");
        return MapToDto(f);
    }

    public async Task<FacturaDto> CreateAsync(CrearFacturaDto dto, int usuarioId)
    {
        if (!dto.Detalles.Any())
            throw new InvalidOperationException("La factura debe tener al menos un producto.");

        var detalles = new List<DetalleFactura>();
        decimal subtotal = 0;

        foreach (var d in dto.Detalles)
        {
            var producto = await _productoRepo.GetByIdAsync(d.ProductoId)
                ?? throw new KeyNotFoundException($"Producto {d.ProductoId} no encontrado.");

            if (producto.StockActual < d.Cantidad)
                throw new InvalidOperationException(
                    $"Stock insuficiente para '{producto.Nombre}'. Disponible: {producto.StockActual}");

            detalles.Add(new DetalleFactura
            {
                ProductoId = d.ProductoId,
                Cantidad = d.Cantidad,
                PrecioUnitario = d.PrecioUnitario
            });
            subtotal += d.Cantidad * d.PrecioUnitario;
        }

        var iva = subtotal * TASA_IVA;
        var total = subtotal + iva;
        var numero = await _facturaRepo.GenerarNumeroFacturaAsync();

        var factura = new Factura
        {
            NumeroFactura = numero,
            ClienteId = dto.ClienteId,
            UsuarioId = usuarioId,
            Detalles = detalles,
            Subtotal = subtotal,
            Iva = iva,
            Total = total
        };

        var creada = await _facturaRepo.CreateAsync(factura);

        // Descontar stock automáticamente
        foreach (var d in dto.Detalles)
        {
            var producto = await _productoRepo.GetByIdAsync(d.ProductoId)!;
            var stockAnterior = producto!.StockActual;
            producto.StockActual -= d.Cantidad;
            await _productoRepo.UpdateAsync(producto);

            await _movRepo.CreateAsync(new MovimientoInventario
            {
                ProductoId = d.ProductoId,
                Tipo = TipoMovimientoInventario.Salida,
                Cantidad = d.Cantidad,
                StockAnterior = stockAnterior,
                StockNuevo = producto.StockActual,
                Referencia = $"FAC-{numero}",
                Motivo = "Venta",
                FacturaId = creada.Id
            });
        }

        return MapToDto(creada);
    }

    public async Task AnularAsync(int id, AnularFacturaDto dto)
    {
        var factura = await _facturaRepo.GetByIdWithDetallesAsync(id)
            ?? throw new KeyNotFoundException($"Factura {id} no encontrada.");

        if (factura.Estado == EstadoFactura.Anulada)
            throw new InvalidOperationException("La factura ya está anulada.");

        factura.Estado = EstadoFactura.Anulada;
        factura.MotivoAnulacion = dto.Motivo;
        factura.FechaAnulacion = DateTime.UtcNow;

        await _facturaRepo.UpdateAsync(factura);
    }

    public async Task<decimal> GetTotalVentasDiaAsync(DateTime fecha) =>
        await _facturaRepo.GetTotalVentasDiaAsync(fecha);

    public async Task<decimal> GetTotalVentasMesAsync(int anio, int mes) =>
        await _facturaRepo.GetTotalVentasMesAsync(anio, mes);

    private static FacturaDto MapToDto(Factura f) => new(
        f.Id, f.NumeroFactura, f.ClienteId, f.Cliente?.Nombre,
        f.FechaEmision, f.Subtotal, f.Iva, f.Total,
        f.Estado.ToString(), f.EnviadaDIAN, f.EnviadaCliente,
        f.Detalles.Select(d => new DetalleFacturaDto(
            d.ProductoId, d.Producto?.Nombre ?? string.Empty,
            d.Cantidad, d.PrecioUnitario, d.Subtotal)));
}
