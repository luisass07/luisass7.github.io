using AsaderoERP.Application.DTOs;
using AsaderoERP.Application.Interfaces;
using AsaderoERP.Domain.Entities;
using AsaderoERP.Domain.Enums;
using AsaderoERP.Domain.Interfaces;

namespace AsaderoERP.Application.Services;

public class ProductoService : IProductoService
{
    private readonly IProductoRepository _productoRepo;
    private readonly IMovimientoInventarioRepository _movRepo;

    public ProductoService(IProductoRepository productoRepo, IMovimientoInventarioRepository movRepo)
    {
        _productoRepo = productoRepo;
        _movRepo = movRepo;
    }

    public async Task<IEnumerable<ProductoDto>> GetAllAsync()
    {
        var productos = await _productoRepo.GetAllAsync();
        return productos.Select(MapToDto);
    }

    public async Task<IEnumerable<ProductoDto>> GetBajoStockAsync()
    {
        var productos = await _productoRepo.GetBajoStockAsync();
        return productos.Select(MapToDto);
    }

    public async Task<ProductoDto> GetByIdAsync(int id)
    {
        var p = await _productoRepo.GetByIdAsync(id)
            ?? throw new KeyNotFoundException($"Producto {id} no encontrado.");
        return MapToDto(p);
    }

    public async Task<ProductoDto> CreateAsync(CrearProductoDto dto)
    {
        if (string.IsNullOrWhiteSpace(dto.Nombre))
            throw new ArgumentException("El nombre del producto es obligatorio.");
        if (dto.PrecioVenta < 0)
            throw new ArgumentException("El precio de venta no puede ser negativo.");

        var producto = new Producto
        {
            Nombre = dto.Nombre,
            Categoria = dto.Categoria,
            Descripcion = dto.Descripcion,
            PrecioVenta = dto.PrecioVenta,
            StockMinimo = dto.StockMinimo,
            UnidadMedida = dto.UnidadMedida
        };

        var creado = await _productoRepo.CreateAsync(producto);
        return MapToDto(creado);
    }

    public async Task<ProductoDto> UpdateAsync(int id, ActualizarProductoDto dto)
    {
        var producto = await _productoRepo.GetByIdAsync(id)
            ?? throw new KeyNotFoundException($"Producto {id} no encontrado.");

        producto.Nombre = dto.Nombre;
        producto.Categoria = dto.Categoria;
        producto.Descripcion = dto.Descripcion;
        producto.PrecioVenta = dto.PrecioVenta;
        producto.StockMinimo = dto.StockMinimo;
        producto.UnidadMedida = dto.UnidadMedida;

        var actualizado = await _productoRepo.UpdateAsync(producto);
        return MapToDto(actualizado);
    }

    public async Task AjustarInventarioAsync(AjusteInventarioDto dto)
    {
        if (dto.NuevaCantidad < 0)
            throw new ArgumentException("La cantidad no puede ser negativa.");

        var producto = await _productoRepo.GetByIdAsync(dto.ProductoId)
            ?? throw new KeyNotFoundException($"Producto {dto.ProductoId} no encontrado.");

        var stockAnterior = producto.StockActual;
        producto.StockActual = dto.NuevaCantidad;
        await _productoRepo.UpdateAsync(producto);

        await _movRepo.CreateAsync(new MovimientoInventario
        {
            ProductoId = dto.ProductoId,
            Tipo = TipoMovimientoInventario.AjusteManual,
            Cantidad = Math.Abs(dto.NuevaCantidad - stockAnterior),
            StockAnterior = stockAnterior,
            StockNuevo = dto.NuevaCantidad,
            Motivo = dto.Motivo
        });
    }

    public async Task<IEnumerable<object>> GetKardexAsync(int productoId)
    {
        if (!await _productoRepo.ExistsAsync(productoId))
            throw new KeyNotFoundException($"Producto {productoId} no encontrado.");

        var movimientos = await _movRepo.GetByProductoAsync(productoId);
        return movimientos.Select(m => (object)new
        {
            m.Id, m.Fecha,
            Tipo = m.Tipo.ToString(),
            m.Cantidad, m.StockAnterior, m.StockNuevo,
            m.Referencia, m.Motivo
        });
    }

    public async Task<decimal> GetCostoPromedioAsync(int productoId)
    {
        var producto = await _productoRepo.GetByIdAsync(productoId)
            ?? throw new KeyNotFoundException($"Producto {productoId} no encontrado.");
        return producto.CostoPromedio;
    }

    private static ProductoDto MapToDto(Producto p) => new(
        p.Id, p.Nombre, p.Categoria, p.Descripcion,
        p.PrecioVenta, p.CostoPromedio, p.StockActual,
        p.StockMinimo, p.UnidadMedida, p.Activo);
}
