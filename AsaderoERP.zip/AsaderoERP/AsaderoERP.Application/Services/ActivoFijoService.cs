using AsaderoERP.Application.DTOs;
using AsaderoERP.Application.Interfaces;
using AsaderoERP.Domain.Entities;
using AsaderoERP.Domain.Enums;
using AsaderoERP.Domain.Interfaces;

namespace AsaderoERP.Application.Services;

public class ActivoFijoService : IActivoFijoService
{
    private readonly IActivoFijoRepository _repo;

    public ActivoFijoService(IActivoFijoRepository repo) => _repo = repo;

    public async Task<IEnumerable<ActivoFijoDto>> GetAllAsync()
    {
        var activos = await _repo.GetAllAsync();
        return activos.Select(MapToDto);
    }

    public async Task<ActivoFijoDto> GetByIdAsync(int id)
    {
        var a = await _repo.GetByIdAsync(id)
            ?? throw new KeyNotFoundException($"Activo fijo {id} no encontrado.");
        return MapToDto(a);
    }

    public async Task<ActivoFijoDto> CreateAsync(CrearActivoFijoDto dto)
    {
        if (string.IsNullOrWhiteSpace(dto.Nombre))
            throw new ArgumentException("El nombre del activo es obligatorio.");
        if (dto.ValorCompra <= 0)
            throw new ArgumentException("El valor de compra debe ser mayor a cero.");
        if (dto.VidaUtilAnios <= 0)
            throw new ArgumentException("La vida útil debe ser mayor a cero.");

        var activo = new ActivoFijo
        {
            Nombre = dto.Nombre,
            Categoria = dto.Categoria,
            Descripcion = dto.Descripcion,
            ValorCompra = dto.ValorCompra,
            FechaAdquisicion = dto.FechaAdquisicion,
            VidaUtilAnios = dto.VidaUtilAnios,
            NumeroSerie = dto.NumeroSerie
        };

        activo.DepreciacionAnual = activo.CalcularDepreciacion();
        activo.ValorActual = activo.CalcularValorActual();

        var creado = await _repo.CreateAsync(activo);
        return MapToDto(creado);
    }

    public async Task<ActivoFijoDto> UpdateAsync(int id, ActualizarActivoFijoDto dto)
    {
        var activo = await _repo.GetByIdAsync(id)
            ?? throw new KeyNotFoundException($"Activo fijo {id} no encontrado.");

        activo.Nombre = dto.Nombre;
        activo.Categoria = dto.Categoria;
        activo.Descripcion = dto.Descripcion;
        activo.ValorCompra = dto.ValorCompra;
        activo.VidaUtilAnios = dto.VidaUtilAnios;
        activo.NumeroSerie = dto.NumeroSerie;
        activo.DepreciacionAnual = activo.CalcularDepreciacion();
        activo.ValorActual = activo.CalcularValorActual();

        var actualizado = await _repo.UpdateAsync(activo);
        return MapToDto(actualizado);
    }

    public async Task DarDeBajaAsync(int id, DarDeBajaActivoDto dto)
    {
        var activo = await _repo.GetByIdAsync(id)
            ?? throw new KeyNotFoundException($"Activo fijo {id} no encontrado.");

        activo.Estado = EstadoActivo.DadoDeBaja;
        activo.FechaBaja = DateTime.UtcNow;
        activo.MotivoBaja = dto.Motivo;

        await _repo.UpdateAsync(activo);
    }

    private static ActivoFijoDto MapToDto(ActivoFijo a) => new(
        a.Id, a.Nombre, a.Categoria, a.Descripcion,
        a.ValorCompra, a.ValorActual, a.FechaAdquisicion,
        a.VidaUtilAnios, a.DepreciacionAnual, a.DepreciacionAcumulada,
        a.Estado.ToString(), a.NumeroSerie);
}
