using AsaderoERP.Application.DTOs;
using AsaderoERP.Application.Interfaces;
using AsaderoERP.Domain.Entities;
using AsaderoERP.Domain.Interfaces;

namespace AsaderoERP.Application.Services;

public class EmpleadoService : IEmpleadoService
{
    private readonly IEmpleadoRepository _empleadoRepo;
    private readonly IAsistenciaRepository _asistenciaRepo;

    public EmpleadoService(IEmpleadoRepository empleadoRepo, IAsistenciaRepository asistenciaRepo)
    {
        _empleadoRepo = empleadoRepo;
        _asistenciaRepo = asistenciaRepo;
    }

    public async Task<IEnumerable<EmpleadoDto>> GetAllAsync()
    {
        var empleados = await _empleadoRepo.GetAllAsync();
        return empleados.Select(MapToDto);
    }

    public async Task<EmpleadoDto> GetByIdAsync(int id)
    {
        var e = await _empleadoRepo.GetByIdAsync(id)
            ?? throw new KeyNotFoundException($"Empleado {id} no encontrado.");
        return MapToDto(e);
    }

    public async Task<EmpleadoDto> CreateAsync(CrearEmpleadoDto dto)
    {
        if (string.IsNullOrWhiteSpace(dto.Nombre) || string.IsNullOrWhiteSpace(dto.Apellido))
            throw new ArgumentException("Nombre y apellido son obligatorios.");
        if (string.IsNullOrWhiteSpace(dto.Cedula))
            throw new ArgumentException("La cédula es obligatoria.");

        var existente = await _empleadoRepo.GetByCedulaAsync(dto.Cedula);
        if (existente != null)
            throw new InvalidOperationException($"Ya existe un empleado con cédula {dto.Cedula}.");

        var empleado = new Empleado
        {
            Nombre = dto.Nombre,
            Apellido = dto.Apellido,
            Cedula = dto.Cedula,
            Cargo = dto.Cargo,
            Telefono = dto.Telefono,
            Email = dto.Email,
            SalarioBase = dto.SalarioBase,
            FechaIngreso = dto.FechaIngreso
        };

        var creado = await _empleadoRepo.CreateAsync(empleado);
        return MapToDto(creado);
    }

    public async Task<EmpleadoDto> UpdateAsync(int id, ActualizarEmpleadoDto dto)
    {
        var empleado = await _empleadoRepo.GetByIdAsync(id)
            ?? throw new KeyNotFoundException($"Empleado {id} no encontrado.");

        empleado.Nombre = dto.Nombre;
        empleado.Apellido = dto.Apellido;
        empleado.Cargo = dto.Cargo;
        empleado.Telefono = dto.Telefono;
        empleado.Email = dto.Email;
        empleado.SalarioBase = dto.SalarioBase;

        var actualizado = await _empleadoRepo.UpdateAsync(empleado);
        return MapToDto(actualizado);
    }

    public async Task EliminarAsync(int id)
    {
        var empleado = await _empleadoRepo.GetByIdAsync(id)
            ?? throw new KeyNotFoundException($"Empleado {id} no encontrado.");

        empleado.Activo = false;
        await _empleadoRepo.UpdateAsync(empleado);
    }

    public async Task<AsistenciaDto> RegistrarEntradaAsync(RegistrarAsistenciaDto dto)
    {
        var empleado = await _empleadoRepo.GetByIdAsync(dto.EmpleadoId)
            ?? throw new KeyNotFoundException($"Empleado {dto.EmpleadoId} no encontrado.");

        var asistencia = new Asistencia
        {
            EmpleadoId = dto.EmpleadoId,
            FechaEntrada = dto.FechaEntrada
        };

        var creada = await _asistenciaRepo.CreateAsync(asistencia);
        return MapAsistenciaToDto(creada, empleado.NombreCompleto);
    }

    public async Task<AsistenciaDto> RegistrarSalidaAsync(int asistenciaId, RegistrarSalidaDto dto)
    {
        var asistencia = await _asistenciaRepo.GetByIdAsync(asistenciaId)
            ?? throw new KeyNotFoundException($"Registro de asistencia {asistenciaId} no encontrado.");

        var empleado = await _empleadoRepo.GetByIdAsync(asistencia.EmpleadoId)!;

        asistencia.FechaSalida = dto.FechaSalida;
        asistencia.CalcularHoras();

        var actualizada = await _asistenciaRepo.UpdateAsync(asistencia);
        return MapAsistenciaToDto(actualizada, empleado!.NombreCompleto);
    }

    public async Task<IEnumerable<AsistenciaDto>> GetAsistenciasAsync(int empleadoId)
    {
        var empleado = await _empleadoRepo.GetByIdAsync(empleadoId)
            ?? throw new KeyNotFoundException($"Empleado {empleadoId} no encontrado.");

        var asistencias = await _asistenciaRepo.GetByEmpleadoAsync(empleadoId);
        return asistencias.Select(a => MapAsistenciaToDto(a, empleado.NombreCompleto));
    }

    public async Task<NominaEmpleadoDto> CalcularNominaAsync(int empleadoId, DateTime desde, DateTime hasta)
    {
        var empleado = await _empleadoRepo.GetByIdAsync(empleadoId)
            ?? throw new KeyNotFoundException($"Empleado {empleadoId} no encontrado.");

        var asistencias = await _asistenciaRepo.GetByPeriodoAsync(empleadoId, desde, hasta);

        var horasTotales = asistencias.Sum(a => a.HorasTrabajadas);

        // Cálculo: salario diario = salarioBase / 30, hora = salarioDiario / 8
        var salarioPorHora = empleado.SalarioBase / 30 / 8;
        var salarioCalculado = horasTotales > 0 ? horasTotales * salarioPorHora : empleado.SalarioBase;

        return new NominaEmpleadoDto(
            empleadoId, empleado.NombreCompleto,
            empleado.SalarioBase, horasTotales,
            salarioCalculado, desde, hasta);
    }

    private static EmpleadoDto MapToDto(Empleado e) => new(
        e.Id, e.Nombre, e.Apellido, e.Cedula,
        e.Cargo, e.Telefono, e.Email,
        e.SalarioBase, e.FechaIngreso, e.Activo);

    private static AsistenciaDto MapAsistenciaToDto(Asistencia a, string nombreEmpleado) => new(
        a.Id, a.EmpleadoId, nombreEmpleado,
        a.FechaEntrada, a.FechaSalida,
        a.HorasTrabajadas, a.Observaciones);
}
