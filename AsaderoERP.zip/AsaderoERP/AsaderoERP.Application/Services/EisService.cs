using AsaderoERP.Application.DTOs;
using AsaderoERP.Application.Interfaces;
using AsaderoERP.Domain.Interfaces;

namespace AsaderoERP.Application.Services;

public class EisService : IEisService
{
    private readonly IFacturaRepository _facturaRepo;
    private readonly IProductoRepository _productoRepo;
    private readonly IEmpleadoRepository _empleadoRepo;
    private readonly IActivoFijoRepository _activoRepo;

    public EisService(
        IFacturaRepository facturaRepo,
        IProductoRepository productoRepo,
        IEmpleadoRepository empleadoRepo,
        IActivoFijoRepository activoRepo)
    {
        _facturaRepo = facturaRepo;
        _productoRepo = productoRepo;
        _empleadoRepo = empleadoRepo;
        _activoRepo = activoRepo;
    }

    public async Task<DashboardDto> GetDashboardAsync()
    {
        var hoy = DateTime.UtcNow;
        var ventasHoy = await _facturaRepo.GetTotalVentasDiaAsync(hoy);
        var ventasMes = await _facturaRepo.GetTotalVentasMesAsync(hoy.Year, hoy.Month);
        var productoBajoStock = await _productoRepo.GetBajoStockAsync();
        var productoMasVendido = await _facturaRepo.GetProductoMasVendidoAsync();
        var empleados = await _empleadoRepo.GetAllAsync();
        var activos = await _activoRepo.GetAllAsync();

        // Ganancia = ventas - costos (simplificado: 30% margen)
        var gananciaMes = ventasMes * 0.30m;

        return new DashboardDto(
            ventasHoy,
            ventasMes,
            gananciaMes,
            productoBajoStock.Count(),
            productoMasVendido?.Nombre,
            empleados.Count(e => e.Activo),
            activos.Count(a => a.Estado == Domain.Enums.EstadoActivo.Activo));
    }

    public async Task<decimal> GetVentasHoyAsync() =>
        await _facturaRepo.GetTotalVentasDiaAsync(DateTime.UtcNow);

    public async Task<decimal> GetVentasMesAsync(int anio, int mes) =>
        await _facturaRepo.GetTotalVentasMesAsync(anio, mes);

    public async Task<string?> GetProductoMasVendidoAsync()
    {
        var producto = await _facturaRepo.GetProductoMasVendidoAsync();
        return producto?.Nombre;
    }

    public async Task<decimal> GetGananciasAsync(DateTime desde, DateTime hasta)
    {
        var facturas = await _facturaRepo.GetByFechaAsync(desde, hasta);
        var totalVentas = facturas
            .Where(f => f.Estado != Domain.Enums.EstadoFactura.Anulada)
            .Sum(f => f.Total);

        // Cálculo simplificado: ganancia = 30% de ventas (se puede refinar con costos reales)
        return totalVentas * 0.30m;
    }

    public async Task<IEnumerable<ProductoBajoStockDto>> GetProductosBajoStockAsync()
    {
        var productos = await _productoRepo.GetBajoStockAsync();
        return productos.Select(p => new ProductoBajoStockDto(
            p.Id, p.Nombre, p.StockActual, p.StockMinimo));
    }
}
