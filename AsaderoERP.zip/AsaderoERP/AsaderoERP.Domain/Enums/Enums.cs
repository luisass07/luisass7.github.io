namespace AsaderoERP.Domain.Enums;

public enum EstadoOrdenCompra
{
    Pendiente = 1,
    Confirmada = 2,
    Recibida = 3,
    Cancelada = 4
}

public enum EstadoFactura
{
    Generada = 1,
    EnviadaDIAN = 2,
    Anulada = 3
}

public enum TipoMovimientoInventario
{
    Entrada = 1,
    Salida = 2,
    AjusteManual = 3
}

public enum EstadoActivo
{
    Activo = 1,
    Inactivo = 2,
    DadoDeBaja = 3
}

public enum RolUsuario
{
    Administrador = 1,
    Cajero = 2,
    Gerente = 3
}
