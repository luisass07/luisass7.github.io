using AsaderoERP.Domain.Enums;

namespace AsaderoERP.Domain.Entities;

public class OrdenCompra
{
    public int Id { get; set; }
    public int ProveedorId { get; set; }
    public Proveedor Proveedor { get; set; } = null!;
    public DateTime FechaCreacion { get; set; } = DateTime.UtcNow;
    public DateTime? FechaRecepcion { get; set; }
    public EstadoOrdenCompra Estado { get; set; } = EstadoOrdenCompra.Pendiente;
    public decimal Total { get; set; }
    public string? Observaciones { get; set; }

    public ICollection<DetalleOrdenCompra> Detalles { get; set; } = new List<DetalleOrdenCompra>();
    public ICollection<HistorialEstadoOrden> Historial { get; set; } = new List<HistorialEstadoOrden>();
}

public class DetalleOrdenCompra
{
    public int Id { get; set; }
    public int OrdenCompraId { get; set; }
    public OrdenCompra OrdenCompra { get; set; } = null!;
    public int ProductoId { get; set; }
    public Producto Producto { get; set; } = null!;
    public decimal Cantidad { get; set; }
    public decimal PrecioUnitario { get; set; }
    public decimal Subtotal => Cantidad * PrecioUnitario;
}

public class HistorialEstadoOrden
{
    public int Id { get; set; }
    public int OrdenCompraId { get; set; }
    public OrdenCompra OrdenCompra { get; set; } = null!;
    public EstadoOrdenCompra EstadoAnterior { get; set; }
    public EstadoOrdenCompra EstadoNuevo { get; set; }
    public DateTime FechaCambio { get; set; } = DateTime.UtcNow;
    public string? Motivo { get; set; }
}
