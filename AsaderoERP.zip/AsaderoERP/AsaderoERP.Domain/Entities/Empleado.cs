namespace AsaderoERP.Domain.Entities;

public class Empleado
{
    public int Id { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public string Apellido { get; set; } = string.Empty;
    public string Cedula { get; set; } = string.Empty;
    public string Cargo { get; set; } = string.Empty;
    public string? Telefono { get; set; }
    public string? Email { get; set; }
    public decimal SalarioBase { get; set; }
    public DateTime FechaIngreso { get; set; }
    public bool Activo { get; set; } = true;
    public DateTime FechaCreacion { get; set; } = DateTime.UtcNow;

    public ICollection<Asistencia> Asistencias { get; set; } = new List<Asistencia>();

    public string NombreCompleto => $"{Nombre} {Apellido}";
}

public class Asistencia
{
    public int Id { get; set; }
    public int EmpleadoId { get; set; }
    public Empleado Empleado { get; set; } = null!;
    public DateTime FechaEntrada { get; set; }
    public DateTime? FechaSalida { get; set; }
    public decimal HorasTrabajadas { get; set; }
    public string? Observaciones { get; set; }

    public void CalcularHoras()
    {
        if (FechaSalida.HasValue)
            HorasTrabajadas = (decimal)(FechaSalida.Value - FechaEntrada).TotalHours;
    }
}
