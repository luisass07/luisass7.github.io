using AsaderoERP.Domain.Enums;

namespace AsaderoERP.Domain.Entities;

public class MovimientoInventario
{
    public int Id { get; set; }
    public int ProductoId { get; set; }
    public Producto Producto { get; set; } = null!;
    public TipoMovimientoInventario Tipo { get; set; }
    public decimal Cantidad { get; set; }
    public decimal StockAnterior { get; set; }
    public decimal StockNuevo { get; set; }
    public DateTime Fecha { get; set; } = DateTime.UtcNow;
    public string? Referencia { get; set; }
    public string? Motivo { get; set; }
    public int? FacturaId { get; set; }
    public int? OrdenCompraId { get; set; }
}
