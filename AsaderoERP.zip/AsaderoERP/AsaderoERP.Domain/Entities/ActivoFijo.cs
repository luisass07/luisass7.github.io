using AsaderoERP.Domain.Enums;

namespace AsaderoERP.Domain.Entities;

public class ActivoFijo
{
    public int Id { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public string Categoria { get; set; } = string.Empty;
    public string? Descripcion { get; set; }
    public decimal ValorCompra { get; set; }
    public decimal ValorActual { get; set; }
    public DateTime FechaAdquisicion { get; set; }
    public int VidaUtilAnios { get; set; }
    public decimal DepreciacionAnual { get; set; }
    public decimal DepreciacionAcumulada { get; set; }
    public EstadoActivo Estado { get; set; } = EstadoActivo.Activo;
    public string? NumeroSerie { get; set; }
    public DateTime FechaCreacion { get; set; } = DateTime.UtcNow;
    public DateTime? FechaBaja { get; set; }
    public string? MotivoBaja { get; set; }

    public decimal CalcularDepreciacion()
    {
        if (VidaUtilAnios <= 0 || ValorCompra <= 0) return 0;
        return ValorCompra / VidaUtilAnios;
    }

    public decimal CalcularValorActual()
    {
        var aniosTranscurridos = (DateTime.UtcNow - FechaAdquisicion).TotalDays / 365;
        var depreciacionTotal = DepreciacionAnual * (decimal)aniosTranscurridos;
        return Math.Max(0, ValorCompra - depreciacionTotal);
    }
}
