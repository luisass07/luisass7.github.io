using AsaderoERP.Domain.Entities;
using AsaderoERP.Domain.Enums;

namespace AsaderoERP.Domain.Interfaces;

public interface IProveedorRepository
{
    Task<IEnumerable<Proveedor>> GetAllAsync();
    Task<Proveedor?> GetByIdAsync(int id);
    Task<Proveedor?> GetByNitAsync(string nit);
    Task<Proveedor> CreateAsync(Proveedor proveedor);
    Task<Proveedor> UpdateAsync(Proveedor proveedor);
    Task<bool> ExistsAsync(int id);
}

public interface IOrdenCompraRepository
{
    Task<IEnumerable<OrdenCompra>> GetAllAsync();
    Task<IEnumerable<OrdenCompra>> GetByProveedorAsync(int proveedorId);
    Task<IEnumerable<OrdenCompra>> GetByFechaAsync(DateTime desde, DateTime hasta);
    Task<OrdenCompra?> GetByIdWithDetallesAsync(int id);
    Task<OrdenCompra> CreateAsync(OrdenCompra orden);
    Task<OrdenCompra> UpdateAsync(OrdenCompra orden);
    Task<bool> DeleteAsync(int id);
    Task<bool> ExistsAsync(int id);
}

public interface IProductoRepository
{
    Task<IEnumerable<Producto>> GetAllAsync();
    Task<IEnumerable<Producto>> GetBajoStockAsync();
    Task<Producto?> GetByIdAsync(int id);
    Task<Producto> CreateAsync(Producto producto);
    Task<Producto> UpdateAsync(Producto producto);
    Task<bool> ExistsAsync(int id);
}

public interface IMovimientoInventarioRepository
{
    Task<IEnumerable<MovimientoInventario>> GetByProductoAsync(int productoId);
    Task<IEnumerable<MovimientoInventario>> GetAllAsync();
    Task<MovimientoInventario> CreateAsync(MovimientoInventario movimiento);
}

public interface IFacturaRepository
{
    Task<IEnumerable<Factura>> GetAllAsync();
    Task<IEnumerable<Factura>> GetByFechaAsync(DateTime desde, DateTime hasta);
    Task<Factura?> GetByIdWithDetallesAsync(int id);
    Task<Factura?> GetByNumeroAsync(string numero);
    Task<Factura> CreateAsync(Factura factura);
    Task<Factura> UpdateAsync(Factura factura);
    Task<string> GenerarNumeroFacturaAsync();
    Task<decimal> GetTotalVentasDiaAsync(DateTime fecha);
    Task<decimal> GetTotalVentasMesAsync(int anio, int mes);
    Task<Producto?> GetProductoMasVendidoAsync();
}

public interface IActivoFijoRepository
{
    Task<IEnumerable<ActivoFijo>> GetAllAsync();
    Task<ActivoFijo?> GetByIdAsync(int id);
    Task<ActivoFijo> CreateAsync(ActivoFijo activo);
    Task<ActivoFijo> UpdateAsync(ActivoFijo activo);
    Task<bool> ExistsAsync(int id);
}

public interface IEmpleadoRepository
{
    Task<IEnumerable<Empleado>> GetAllAsync();
    Task<Empleado?> GetByIdAsync(int id);
    Task<Empleado?> GetByCedulaAsync(string cedula);
    Task<Empleado> CreateAsync(Empleado empleado);
    Task<Empleado> UpdateAsync(Empleado empleado);
    Task<bool> ExistsAsync(int id);
}

public interface IAsistenciaRepository
{
    Task<IEnumerable<Asistencia>> GetByEmpleadoAsync(int empleadoId);
    Task<IEnumerable<Asistencia>> GetByPeriodoAsync(int empleadoId, DateTime desde, DateTime hasta);
    Task<Asistencia> CreateAsync(Asistencia asistencia);
    Task<Asistencia> UpdateAsync(Asistencia asistencia);
    Task<Asistencia?> GetByIdAsync(int id);
}

public interface IUsuarioRepository
{
    Task<Usuario?> GetByEmailAsync(string email);
    Task<Usuario?> GetByIdAsync(int id);
    Task<Usuario> CreateAsync(Usuario usuario);
    Task<Usuario> UpdateAsync(Usuario usuario);
    Task<bool> ExistsAsync(string email);
}
