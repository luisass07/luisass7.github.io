# 🔥 Asadero ERP — API REST en C# (.NET 8)

Sistema ERP completo para gestión de asadero, construido con **Clean Architecture**, **ASP.NET Core 8**, **Entity Framework Core** y **MySQL**.

---

## 📐 Arquitectura

```
AsaderoERP/
├── AsaderoERP.Domain/          # Entidades, Enums, Interfaces de repositorios
├── AsaderoERP.Application/     # DTOs, Interfaces de servicios, Servicios
├── AsaderoERP.Infrastructure/  # DbContext (EF Core + MySQL), Repositorios
└── AsaderoERP.API/             # Controllers, Middleware, Program.cs
```

---

## 📦 Módulos implementados

| Módulo              | Historias cubiertas                                             |
|---------------------|-----------------------------------------------------------------|
| **Compras**         | Proveedores, órdenes de compra, recepción, cancelar, eliminar   |
| **Facturación**     | Generar factura, anular, ventas diarias/mensuales               |
| **Inventario**      | Productos, stock, kardex, ajuste manual, costo promedio, alertas|
| **Activos Fijos**   | Registro, edición, depreciación automática, baja de activos     |
| **Empleados**       | Registro, asistencia (entrada/salida), cálculo de nómina        |
| **EIS / Dashboard** | Dashboard ejecutivo, ventas, ganancias, bajo stock              |
| **Autenticación**   | JWT con roles: Administrador, Cajero, Gerente                   |

---

## 🚀 Cómo ejecutar el proyecto

### 1. Requisitos previos
- .NET 8 SDK
- MySQL 8.x o MariaDB 10.x
- Visual Studio 2022 o VS Code

### 2. Configurar la base de datos

Editar `AsaderoERP.API/appsettings.json`:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost;Port=3306;Database=AsaderoERP;User=root;Password=TuPassword;"
  },
  "JwtSettings": {
    "SecretKey": "TuClaveSecretaMuyLarga_CambiarEnProduccion!",
    "Issuer": "AsaderoERP.API",
    "Audience": "AsaderoERP.Clients"
  }
}
```

### 3. Aplicar migraciones

```bash
cd AsaderoERP/AsaderoERP.API
dotnet ef migrations add InitialCreate --project ../AsaderoERP.Infrastructure
dotnet ef database update
```

### 4. Ejecutar la API

```bash
dotnet run --project AsaderoERP.API
```

La API estará disponible en `https://localhost:5001` con Swagger en la raíz.

---

## 🔐 Autenticación

### Usuario administrador por defecto
- **Email:** `admin@asadero.com`
- **Password:** `Admin123!`

### Flujo de autenticación

```http
POST /api/Auth/login
Content-Type: application/json

{
  "email": "admin@asadero.com",
  "password": "Admin123!"
}
```

La respuesta incluye el token JWT. Úsalo en todas las peticiones:
```
Authorization: Bearer {token}
```

---

## 📋 Endpoints principales

### Compras
| Método | Endpoint                                    | Descripción              | Rol          |
|--------|---------------------------------------------|--------------------------|--------------|
| GET    | `/api/Proveedores`                          | Listar proveedores        | Admin        |
| POST   | `/api/Proveedores`                          | Registrar proveedor       | Admin        |
| GET    | `/api/OrdenesCompra`                        | Listar órdenes            | Admin        |
| POST   | `/api/OrdenesCompra`                        | Crear orden               | Admin        |
| PATCH  | `/api/OrdenesCompra/{id}/confirmar-recepcion` | Confirmar recepción     | Admin        |
| PATCH  | `/api/OrdenesCompra/{id}/cancelar`          | Cancelar orden            | Admin        |

### Facturación
| Método | Endpoint                        | Descripción             | Rol               |
|--------|---------------------------------|-------------------------|-------------------|
| POST   | `/api/Facturas`                 | Generar factura         | Cajero, Admin     |
| GET    | `/api/Facturas`                 | Listar facturas         | Admin, Gerente    |
| PATCH  | `/api/Facturas/{id}/anular`     | Anular factura          | Admin             |
| GET    | `/api/Facturas/ventas-dia`      | Total ventas del día    | Admin, Gerente    |
| GET    | `/api/Facturas/ventas-mes`      | Total ventas del mes    | Admin, Gerente    |

### Inventario
| Método | Endpoint                           | Descripción              | Rol            |
|--------|------------------------------------|--------------------------|----------------|
| GET    | `/api/Productos`                   | Listar productos         | Admin, Gerente |
| POST   | `/api/Productos`                   | Registrar producto       | Admin          |
| GET    | `/api/Productos/bajo-stock`        | Productos bajo stock     | Admin, Gerente |
| PATCH  | `/api/Productos/ajuste`            | Ajuste manual            | Admin          |
| GET    | `/api/Productos/{id}/kardex`       | Historial movimientos    | Admin, Gerente |
| GET    | `/api/Productos/{id}/costo-promedio` | Costo promedio         | Admin, Gerente |

### Empleados
| Método | Endpoint                                    | Descripción         | Rol   |
|--------|---------------------------------------------|---------------------|-------|
| GET    | `/api/Empleados`                            | Listar empleados    | Admin |
| POST   | `/api/Empleados`                            | Registrar empleado  | Admin |
| POST   | `/api/Empleados/asistencia/entrada`         | Registrar entrada   | Admin |
| PATCH  | `/api/Empleados/asistencia/{id}/salida`     | Registrar salida    | Admin |
| GET    | `/api/Empleados/{id}/nomina`                | Calcular nómina     | Admin |

### EIS Dashboard
| Método | Endpoint                     | Descripción              | Rol              |
|--------|------------------------------|--------------------------|------------------|
| GET    | `/api/Eis/dashboard`         | Dashboard completo       | Admin, Gerente   |
| GET    | `/api/Eis/ventas-hoy`        | Ventas del día           | Admin, Gerente   |
| GET    | `/api/Eis/ventas-mes`        | Ventas mensuales         | Admin, Gerente   |
| GET    | `/api/Eis/producto-mas-vendido` | Producto top          | Admin, Gerente   |
| GET    | `/api/Eis/ganancias`         | Ganancias por periodo    | Admin, Gerente   |
| GET    | `/api/Eis/bajo-stock`        | Alertas de stock         | Admin, Gerente   |

---

## 🔄 Flujos automáticos

- **Confirmación de compra** → actualiza stock + registra movimiento en kardex + recalcula costo promedio
- **Generación de factura** → descuenta stock + registra salida en kardex
- **Alertas de stock** → se activan cuando `StockActual <= StockMinimo`
- **Depreciación** → se calcula automáticamente al crear/editar activos fijos

---

## 🛠️ Tecnologías

| Tecnología                | Versión  | Uso                       |
|---------------------------|----------|---------------------------|
| .NET / ASP.NET Core       | 8.0      | Framework principal       |
| Entity Framework Core     | 8.0.8    | ORM                       |
| Pomelo.EFCore.MySql       | 8.0.2    | Driver MySQL              |
| BCrypt.Net-Next           | 4.0.3    | Hash de contraseñas       |
| System.IdentityModel.Tokens.Jwt | 7.5.2 | Generación JWT         |
| Swashbuckle (Swagger)     | 6.8.1    | Documentación API         |
